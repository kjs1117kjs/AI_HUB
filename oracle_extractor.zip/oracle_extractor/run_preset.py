"""
run_preset.py — 저장된 작업(프리셋)을 브라우저·서버 없이 실행 (예약 실행용)

사용:
    python run_preset.py "프리셋이름"
    python run_preset.py "프리셋이름" --xlsx        # 엑셀 병합도 생성

Windows 작업 스케줄러(schtasks)에 이 명령을 등록하면 정해진 시각에 자동 추출됩니다.
결과는 output/scheduled/<프리셋>_<날짜시각>/ 아래에 쌓입니다.
비밀번호는 프리셋에 저장되지 않으므로, 자동 실행에는 아래 중 하나가 필요합니다.
  - 환경변수 ORA_PW 로 비밀번호 전달
  - 데모 프리셋(비밀번호 불필요)
"""

import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

import extractor as ex

BASE = Path(__file__).resolve().parent
PRESETS = BASE / "presets.json"


def load_preset(name):
    if not PRESETS.exists():
        sys.exit("presets.json 이 없습니다. 먼저 화면에서 작업을 저장하세요.")
    data = json.loads(PRESETS.read_text(encoding="utf-8"))
    if name not in data:
        sys.exit(f"'{name}' 프리셋을 찾을 수 없습니다. 저장된 이름: {', '.join(data) or '(없음)'}")
    return data[name]


def to_cfg(c):
    splits = [ex.SplitDim(**s) for s in c.get("splits", [])]
    c = {k: v for k, v in c.items() if k != "splits"}
    c.pop("db_password", None)
    cfg = ex.ExtractConfig(splits=splits, **c)
    cfg.db_password = os.environ.get("ORA_PW", "")   # 비밀번호는 환경변수로
    return cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("preset")
    ap.add_argument("--xlsx", action="store_true", help="구간 CSV를 엑셀 하나로 병합")
    args = ap.parse_args()

    cfg = to_cfg(load_preset(args.preset))
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = BASE / "output" / "scheduled" / f"{args.preset}_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    def emit(e):
        t = e.get("type")
        if t == "start":
            print(f"[{stamp}] 시작 · {e['total_chunks']}개 구간 · 병렬 {e['parallel']}")
        elif t == "chunk_done":
            print(f"  [{e['index']}/{e['total']}] {e['label']} → {e['status']} "
                  f"{e.get('rows','')}건 {e.get('elapsed','')}s")
        elif t == "done":
            print(f"완료 · 총 {e['total_rows']:,}건 · 파일 {e['file_count']}개 · {e['elapsed']}s")

    result = ex.run_extraction(cfg, str(out), emit=emit)

    if args.xlsx and result["files"]:
        from xlsx_merge import merge_to_xlsx
        xpath = out / f"{args.preset}_{stamp}.xlsx"
        merge_to_xlsx([out / f for f in result["files"]], xpath)
        print(f"엑셀 병합: {xpath}")

    print(f"저장 위치: {out}")


if __name__ == "__main__":
    main()
