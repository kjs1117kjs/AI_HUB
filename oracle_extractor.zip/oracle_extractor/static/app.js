/* ============================================================
   매출 추출 콘솔 — 프론트엔드 로직 (다차원 분할 + 프리셋)
   ============================================================ */
const $ = (id) => document.getElementById(id);
const nf = new Intl.NumberFormat("ko-KR");
const won = (n) => "₩" + nf.format(Math.round(n));

let currentJob = null;
let evtSource = null;
let charts = { date: null, store: null, product: null };
let totalChunks = 0;

/* ── 분할 축 상태 ─────────────────────────────── */
let dims = [];   // {type, column, start, end, step, pad, values, batch}

function defaultDim(type) {
  if (type === "date")
    return { type, column: "tsdps.SALE_DATE", start: "20241201", end: "20241206", step: 3 };
  if (type === "range")
    return { type, column: "tsdps.STORE_CD", start: "1", end: "100", step: 10, pad: 4 };
  return { type: "list", column: "tsdps.STORE_CD", values: "", batch: 3 };
}

/* 시작 시 기본 = 날짜 3일 분할 (기존 동작과 동일) */
dims.push(defaultDim("date"));

/* ── 분할 빌더 렌더링 ─────────────────────────── */
const dimList = $("dimList");

function renderDims() {
  dimList.innerHTML = "";
  dims.forEach((d, idx) => dimList.appendChild(dimCard(d, idx)));
  updateSplitCount();
}

function dimCard(d, idx) {
  const el = document.createElement("div");
  el.className = "dim";
  const typeName = { date: "날짜 범위", range: "코드 범위", list: "코드 목록" }[d.type];

  let body = "";
  if (d.type === "date") {
    body = `
      <div class="field-row">
        <div class="field"><label>시작일</label><input type="date" data-k="start" value="${ymd2date(d.start)}" /></div>
        <div class="field"><label>종료일</label><input type="date" data-k="end" value="${ymd2date(d.end)}" /></div>
      </div>
      <div class="field"><label>며칠 단위 <b class="mono">${d.step}</b>일</label>
        <input type="range" min="1" max="31" data-k="step" value="${d.step}" /></div>`;
  } else if (d.type === "range") {
    body = `
      <div class="field-row">
        <div class="field"><label>시작 코드(숫자)</label><input type="text" data-k="start" value="${d.start}" /></div>
        <div class="field"><label>끝 코드(숫자)</label><input type="text" data-k="end" value="${d.end}" /></div>
      </div>
      <div class="field-row">
        <div class="field"><label>몇 개씩 증가</label><input type="number" min="1" data-k="step" value="${d.step}" /></div>
        <div class="field"><label>자리수(0=없음)</label><input type="number" min="0" data-k="pad" value="${d.pad}" /></div>
      </div>`;
  } else {
    body = `
      <div class="field"><label>코드 목록 (쉼표·공백·줄바꿈 구분, SQL의 IN(...) 통째로 붙여넣기 OK)</label>
        <textarea data-k="values" rows="4" placeholder="예)
'DS00001','DS00002','DS00003'
또는 IN ('DS00001', 'DS00002', ...) 통째로 붙여넣기">${Array.isArray(d.values) ? d.values.join(", ") : d.values}</textarea></div>
      <div class="field"><label>몇 개씩 묶음</label><input type="number" min="1" data-k="batch" value="${d.batch}" /></div>`;
  }

  el.innerHTML = `
    <div class="dim__head">
      <span class="dim__badge dim__badge--${d.type}">${typeName}</span>
      <button class="dim__rm" title="이 축 삭제">✕</button>
    </div>
    <div class="field"><label>대상 컬럼</label>
      <input type="text" list="colOptions" data-k="column" value="${d.column}" /></div>
    ${body}`;

  // 이벤트 바인딩
  el.querySelector(".dim__rm").addEventListener("click", () => { dims.splice(idx, 1); renderDims(); });
  el.querySelectorAll("[data-k]").forEach((inp) => {
    const evt = inp.type === "range" ? "input" : "change";
    inp.addEventListener(evt, () => {
      const k = inp.dataset.k;
      let v = inp.value;
      if (inp.type === "date") v = v.replaceAll("-", "");
      if (["step", "pad", "batch"].includes(k)) v = parseInt(v || "0", 10);
      dims[idx][k] = v;
      if (inp.type === "range") { const b = inp.closest(".field").querySelector("b"); if (b) b.textContent = v; }
      updateSplitCount();
    });
  });
  return el;
}

function ymd2date(s) {
  if (!s || s.length !== 8) return "";
  return `${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}`;
}

/* ── 구간 수 계산 (클라이언트 추정) ───────────── */
function dimChunkCount(d) {
  try {
    if (d.type === "date") {
      const s = new Date(ymd2date(d.start)), e = new Date(ymd2date(d.end));
      const days = Math.floor((e - s) / 86400000) + 1;
      return days > 0 ? Math.ceil(days / Math.max(1, d.step)) : 0;
    }
    if (d.type === "range") {
      const n = parseInt(d.end, 10) - parseInt(d.start, 10) + 1;
      return n > 0 ? Math.ceil(n / Math.max(1, d.step)) : 0;
    }
    const vals = normValues(d.values);
    return vals.length ? Math.ceil(vals.length / Math.max(1, d.batch)) : 0;
  } catch { return 0; }
}
function updateSplitCount() {
  if (!dims.length) { $("splitCount").textContent = "전체 1구간"; return; }
  const counts = dims.map(dimChunkCount);
  const total = counts.reduce((a, b) => a * b, 1);
  $("splitCount").textContent = `${counts.join(" × ")} = ${total}구간`;
}

$("dimList");
document.querySelectorAll("[data-add]").forEach((btn) =>
  btn.addEventListener("click", () => { dims.push(defaultDim(btn.dataset.add)); renderDims(); }));

$("sleepSec").addEventListener("input", (e) => { $("sleepLabel").textContent = parseFloat(e.target.value).toFixed(1); });
$("parallel").addEventListener("input", (e) => { $("parallelLabel").textContent = e.target.value; });

/* ── 쿼리 모드 토글 ───────────────────────────── */
let defaultQueryCache = null;
async function fetchDefaultQuery() {
  if (defaultQueryCache) return defaultQueryCache;
  try {
    const r = await fetch("/api/default-query");
    const d = await r.json();
    defaultQueryCache = d.query || "";
  } catch { defaultQueryCache = ""; }
  return defaultQueryCache;
}
function setQueryMode(mode) {
  document.querySelectorAll("#qmodeToggle button").forEach((b) =>
    b.classList.toggle("active", b.dataset.qmode === mode));
  const custom = mode === "custom";
  $("qCustomBox").hidden = !custom;
  $("qAutoNote").hidden = custom;
}
document.querySelectorAll("#qmodeToggle button").forEach((btn) =>
  btn.addEventListener("click", async () => {
    setQueryMode(btn.dataset.qmode);
    if (btn.dataset.qmode === "custom" && !$("customQuery").value.trim()) {
      $("customQuery").value = await fetchDefaultQuery();
    }
  }));
$("btnLoadDefault").addEventListener("click", async () => {
  if ($("customQuery").value.trim() && !confirm("현재 편집 내용을 기본 쿼리로 덮어쓸까요?")) return;
  $("customQuery").value = await fetchDefaultQuery();
});

renderDims();

/* ── 설정 수집 ────────────────────────────────── */
function normValues(v) {
  let s = Array.isArray(v) ? v.join(",") : (v || "");
  // 붙여넣은 SQL 조각 관용 처리: 앞부분의 컬럼 IN ( ... ) 껍데기 제거
  s = s.replace(/\bIN\b/gi, " ").replace(/[()]/g, " ");
  // 따옴표 안 값이 있으면 그것만, 없으면 콤마/공백/줄바꿈으로 분리
  const quoted = s.match(/'([^']+)'|"([^"]+)"/g);
  let arr;
  if (quoted && quoted.length) {
    arr = quoted.map((x) => x.replace(/['"]/g, "").trim());
  } else {
    arr = s.split(/[\s,;]+/).map((x) => x.trim());
  }
  // 중복 제거 + 빈 값 제거 (순서 유지)
  const seen = new Set();
  return arr.filter((x) => x && !seen.has(x) && seen.add(x));
}
function collectConfig() {
  const brands = [...document.querySelectorAll("#brandChips input:checked")].map((c) => c.value);
  const qmode = document.querySelector("#qmodeToggle .active")?.dataset.qmode || "auto";
  const splits = dims.map((d) => ({
    type: d.type, column: d.column,
    start: d.start || "", end: d.end || "",
    step: parseInt(d.step || 1, 10), pad: parseInt(d.pad || 0, 10),
    values: d.type === "list" ? normValues(d.values) : [],
    batch: parseInt(d.batch || 10, 10),
  }));
  return {
    db_user: $("dbUser").value.trim(),
    db_password: $("dbPassword").value,
    db_dsn: $("dbDsn").value.trim(),
    office_cd: $("officeCd").value.trim(),
    brand_codes: brands,
    splits,
    sleep_sec: parseFloat($("sleepSec").value),
    arraysize: parseInt($("arraysize").value, 10),
    save_empty: $("saveEmpty").checked,
    demo: $("demoMode").checked,
    max_retries: parseInt($("maxRetries").value || 0, 10),
    retry_delay: parseFloat($("retryDelay").value || 0),
    parallel: parseInt($("parallel").value || 1, 10),
    query_mode: qmode,
    custom_query: $("customQuery").value,
    apply_split: $("applySplit").checked,
    max_rows_per_file: parseInt($("maxRowsPerFile").value || 0, 10),
    dooray_enabled: $("doorayEnabled").checked,
    dooray_url: $("doorayWebhook").value.trim(),
    dooray_webhook: $("doorayEnabled").checked ? $("doorayWebhook").value.trim() : "",
    email: {
      enabled: $("emailEnabled").checked,
      host: $("smtpHost").value.trim(),
      port: parseInt($("smtpPort").value || 587, 10),
      user: $("smtpUser").value.trim(),
      password: $("smtpPass").value,
      to: $("mailTo").value.trim(),
      subject: $("mailSubject").value,
      as_xlsx: $("mailXlsx").checked,
    },
  };
}

/* ── 설정 적용 (프리셋 불러오기) ──────────────── */
function applyConfig(c) {
  if (!c) return;
  $("officeCd").value = c.office_cd || "";
  $("arraysize").value = c.arraysize || 5000;
  $("saveEmpty").checked = !!c.save_empty;
  $("sleepSec").value = c.sleep_sec ?? 1;
  $("sleepLabel").textContent = parseFloat(c.sleep_sec ?? 1).toFixed(1);
  $("maxRetries").value = c.max_retries ?? 1;
  $("retryDelay").value = c.retry_delay ?? 2;
  $("parallel").value = c.parallel ?? 1;
  $("parallelLabel").textContent = c.parallel ?? 1;
  if (c.email) {
    $("emailEnabled").checked = !!c.email.enabled;
    $("smtpHost").value = c.email.host || "";
    $("smtpPort").value = c.email.port || 587;
    $("smtpUser").value = c.email.user || "";
    $("mailTo").value = c.email.to || "";
    $("mailSubject").value = c.email.subject || "매출 추출 결과";
    $("mailXlsx").checked = c.email.as_xlsx !== false;
  }
  // 쿼리 모드
  $("customQuery").value = c.custom_query || "";
  $("applySplit").checked = c.apply_split !== false;
  $("maxRowsPerFile").value = c.max_rows_per_file ?? 0;
  if (c.dooray_url !== undefined || c.dooray_webhook !== undefined)
    $("doorayWebhook").value = c.dooray_url || c.dooray_webhook || "";
  $("doorayEnabled").checked = !!c.dooray_enabled;
  // 드롭다운을 저장된 URL과 동기화
  const dsel = $("doorayPreset");
  dsel.value = [...dsel.options].some((o) => o.value === $("doorayWebhook").value)
    ? $("doorayWebhook").value : "";
  setQueryMode(c.query_mode === "custom" ? "custom" : "auto");
  if (c.db_user) $("dbUser").value = c.db_user;
  if (c.db_dsn) $("dbDsn").value = c.db_dsn;

  // 브랜드
  const want = new Set(c.brand_codes || []);
  $("brandChips").innerHTML = "";
  (c.brand_codes || ["100","101","102","114"]).forEach((v) => addBrandChip(v, true));

  // 분할 축
  dims = (c.splits || []).map((s) => ({
    type: s.type, column: s.column,
    start: s.start, end: s.end, step: s.step, pad: s.pad,
    values: Array.isArray(s.values) ? s.values.join(", ") : (s.values || ""),
    batch: s.batch,
  }));
  if (!dims.length) dims.push(defaultDim("date"));
  renderDims();
}

/* ── 브랜드 칩 ────────────────────────────────── */
function addBrandChip(v, checked) {
  const label = document.createElement("label");
  label.className = "chip";
  label.innerHTML = `<input type="checkbox" value="${v}" ${checked ? "checked" : ""}/><span>${v}</span>`;
  $("brandChips").appendChild(label);
}
$("btnBrandAdd").addEventListener("click", addBrand);
$("brandNew").addEventListener("keydown", (e) => { if (e.key === "Enter") addBrand(); });
function addBrand() {
  const v = $("brandNew").value.trim();
  if (!/^[A-Za-z0-9]+$/.test(v)) { $("brandNew").focus(); return; }
  if ([...document.querySelectorAll("#brandChips input")].some((c) => c.value === v)) { $("brandNew").value = ""; return; }
  addBrandChip(v, true);
  $("brandNew").value = "";
}

/* ── 프리셋 ───────────────────────────────────── */
async function loadPresetNames() {
  try {
    const r = await fetch("/api/presets");
    const d = await r.json();
    const sel = $("presetSelect");
    sel.innerHTML = `<option value="">불러올 작업 선택…</option>` +
      d.names.map((n) => `<option value="${n}">${n}</option>`).join("");
  } catch { /* 무시 */ }
}
$("btnSavePreset").addEventListener("click", async () => {
  const name = prompt("이 작업을 어떤 이름으로 저장할까요?");
  if (!name) return;
  const r = await fetch("/api/presets", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: name.trim(), config: collectConfig() }),
  });
  if (r.ok) { await loadPresetNames(); $("presetSelect").value = name.trim(); }
  else alert("저장 실패");
});
$("presetSelect").addEventListener("change", async (e) => {
  const name = e.target.value;
  if (!name) return;
  const r = await fetch(`/api/presets/${encodeURIComponent(name)}`);
  if (!r.ok) return;
  const d = await r.json();
  applyConfig(d.config);
});
$("btnDeletePreset").addEventListener("click", async () => {
  const name = $("presetSelect").value;
  if (!name) return;
  if (!confirm(`'${name}' 저장 작업을 삭제할까요?`)) return;
  await fetch(`/api/presets/${encodeURIComponent(name)}`, { method: "DELETE" });
  await loadPresetNames();
});
loadPresetNames();

/* ── 연결 테스트 ──────────────────────────────── */
$("btnTest").addEventListener("click", async () => {
  setPill("testing", "확인 중…"); setConnMsg("", "");
  try {
    const r = await fetch("/api/test-connection", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(collectConfig()),
    });
    const d = await r.json();
    setPill(d.ok ? "ok" : "fail", d.ok ? "연결됨" : "실패");
    setConnMsg(d.message, d.ok ? "ok" : "fail");
  } catch (e) { setPill("fail", "실패"); setConnMsg("요청 실패: " + e.message, "fail"); }
});
function setPill(state, text) { $("connPill").dataset.state = state; $("connPillText").textContent = text; }
function setConnMsg(msg, state) { const el = $("connMsg"); el.textContent = msg; el.dataset.state = state || ""; }

/* ── 쿼리 미리보기 ────────────────────────────── */
$("btnPreview").addEventListener("click", async () => {
  const r = await fetch("/api/preview-query", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(collectConfig()),
  });
  const d = await r.json();
  if (!d.ok) { alert(d.message); return; }
  $("queryText").textContent = d.query;
  const shown = d.labels.slice(0, 40).join(" · ") + (d.labels.length > 40 ? " …" : "");
  $("chunkSummary").innerHTML =
    `총 <b>${d.task_count}</b>개 구간 · 예상 대기 ${d.est_seconds_wait}초<br><span class="mono" style="font-size:11px">${shown}</span>`;
  $("queryModal").hidden = false;
});
$("btnModalClose").addEventListener("click", () => { $("queryModal").hidden = true; });
$("queryModal").addEventListener("click", (e) => { if (e.target === $("queryModal")) $("queryModal").hidden = true; });

/* ── 추출 시작 ────────────────────────────────── */
$("btnRun").addEventListener("click", async () => {
  const cfg = collectConfig();
  if (!cfg.demo && (!cfg.db_user || !cfg.db_dsn)) {
    if (!confirm("접속 정보가 비어 있습니다. 데모 모드가 아니면 실패할 수 있어요. 계속할까요?")) return;
  }
  resetRun();
  let d;
  try {
    const r = await fetch("/api/jobs", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(cfg),
    });
    if (!r.ok) { const err = await r.json(); throw new Error(err.detail || "작업 생성 실패"); }
    d = await r.json();
  } catch (e) { logLine("error", `작업을 시작하지 못했습니다: ${e.message}`); return; }
  currentJob = d.job_id;
  setRunning(true);
  streamJob(d.job_id);
});

/* ── 중단 ─────────────────────────────────────── */
$("btnStop").addEventListener("click", async () => {
  if (!currentJob) return;
  await fetch(`/api/jobs/${currentJob}/cancel`, { method: "POST" });
  $("runStatus").textContent = "중단 요청됨 — 현재 구간까지 마치고 멈춥니다…";
});

/* ── SSE 스트림 ───────────────────────────────── */
function streamJob(jobId) {
  evtSource = new EventSource(`/api/jobs/${jobId}/stream`);
  evtSource.onmessage = (ev) => handleEvent(JSON.parse(ev.data));
  evtSource.onerror = () => { if (evtSource) { evtSource.close(); evtSource = null; } };
}

function handleEvent(e) {
  switch (e.type) {
    case "start":
      totalChunks = e.total_chunks;
      buildRail(totalChunks);
      $("progressLabel").textContent = `0 / ${totalChunks}`;
      logLine("head", `▶ 추출 시작 · ${totalChunks}개 구간 · 축 ${e.dims}개 · 쉬는시간 ${e.sleep_sec}s` +
        (e.demo ? " · [데모]" : "") + ` · arraysize=${nf.format(e.arraysize)}`);
      $("runStatus").innerHTML = `실행 중 — 총 <b>${totalChunks}</b>개 구간`;
      break;
    case "log":
      if (e.level === "wait") logLine("empty", `    · ${e.msg}`);
      break;
    case "chunk_start":
      setSeg(e.index - 1, "active");
      logLine("info", `[<b>${e.index}/${e.total}</b>] ${e.label} 조회 중…`);
      upsertChunkRow(e.index, e.label, "run");
      break;
    case "chunk_done": {
      const s = e.status;
      setSeg(e.index - 1, s === "ok" ? "ok" : s);
      if (s === "ok") {
        const partTxt = e.parts > 1 ? ` · ${e.parts}개 파일로 분할` : ` · ${e.file}`;
        logLine("ok", `    → ${nf.format(e.rows)}건${partTxt} · ${e.elapsed}s`);
      }
      else if (s === "empty") logLine("empty", `    → 0건, 건너뜀 · ${e.elapsed}s`);
      else logLine("error", `    → 오류: ${e.error} · ${e.elapsed}s`);
      upsertChunkRow(e.index, e.label, s, s === "ok" ? e.rows : 0, e.elapsed);
      break;
    }
    case "progress": {
      const pct = Math.round((e.done / e.total) * 100);
      $("progressBar").style.setProperty("--p", pct + "%");
      $("progressLabel").textContent = `${e.done} / ${e.total}`;
      break;
    }
    case "cancelled":
      logLine("error", `■ 사용자 중단 · ${e.done}/${e.total} 구간 완료`); break;
    case "done":
      logLine("head", `✔ 완료 · 총 ${nf.format(e.total_rows)}건 · 파일 ${e.file_count}개 · 전체 ${e.elapsed}s`);
      $("runStatus").innerHTML = `완료 — <b>${nf.format(e.total_rows)}</b>건 · 파일 ${e.file_count}개 · ${e.elapsed}s`;
      renderResults(e); break;
    case "error":
      logLine("error", `✖ 오류: ${e.msg}`); $("runStatus").textContent = "오류로 중단되었습니다."; break;
    case "end":
      setRunning(false); if (evtSource) { evtSource.close(); evtSource = null; } break;
  }
}

/* ── 파이프라인 레일 ──────────────────────────── */
function buildRail(n) {
  const rail = $("rail"); rail.innerHTML = "";
  for (let i = 0; i < n; i++) {
    const seg = document.createElement("div");
    seg.className = "seg"; seg.dataset.s = "idle"; rail.appendChild(seg);
  }
}
function setSeg(i, state) { const seg = $("rail").children[i]; if (seg) seg.dataset.s = state; }

/* ── 로그 ─────────────────────────────────────── */
function logLine(cls, html) {
  const body = $("logBody");
  const empty = body.querySelector(".log-empty"); if (empty) empty.remove();
  const t = new Date().toLocaleTimeString("ko-KR", { hour12: false });
  const line = document.createElement("div");
  line.className = `log-line ${cls}`;
  line.innerHTML = `<span class="t">${t}</span><span>${html}</span>`;
  body.appendChild(line); body.scrollTop = body.scrollHeight;
}

/* ── 구간 테이블 ──────────────────────────────── */
function upsertChunkRow(idx, label, status, rows, elapsed) {
  const tbody = $("chunkRows");
  const empty = tbody.querySelector(".tbl-empty"); if (empty) empty.remove();
  let tr = tbody.querySelector(`tr[data-i="${idx}"]`);
  if (!tr) { tr = document.createElement("tr"); tr.dataset.i = idx; tbody.appendChild(tr); }
  const tagMap = {
    run: `<span class="tag tag--run">조회중</span>`, ok: `<span class="tag tag--ok">완료</span>`,
    empty: `<span class="tag tag--empty">0건</span>`, error: `<span class="tag tag--error">오류</span>`,
  };
  tr.innerHTML =
    `<td>${idx}</td><td class="ellip" title="${label}">${label}</td>` +
    `<td class="ta-r">${rows != null ? nf.format(rows) : "—"}</td>` +
    `<td class="ta-r">${elapsed != null ? elapsed : "—"}</td>` +
    `<td>${tagMap[status] || ""}</td>`;
}

/* ── 실행 상태 ────────────────────────────────── */
function setRunning(on) { $("btnRun").disabled = on; $("btnStop").disabled = !on; $("btnPreview").disabled = on; }
function resetRun() {
  $("logBody").innerHTML = "";
  $("chunkRows").innerHTML = `<tr class="tbl-empty"><td colspan="5">아직 실행된 구간이 없습니다.</td></tr>`;
  $("rail").innerHTML = "";
  $("progressBar").style.setProperty("--p", "0%");
  $("progressLabel").textContent = "0 / 0";
  $("results").hidden = true;
}

/* ── 결과 렌더링 ──────────────────────────────── */
function renderResults(e) {
  const c = e.chart;
  const totalReal = (c.by_date.real || []).reduce((a, b) => a + b, 0);
  $("summary").innerHTML = `
    ${statCard("총 추출 건수", nf.format(e.total_rows), "건", true)}
    ${statCard("생성 파일", nf.format(e.file_count), "개")}
    ${statCard("실매출 합계", won(totalReal), "")}
    ${statCard("전체 수행시간", e.elapsed, "초")}`;
  const dlIcon = `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 19h16"/></svg>`;
  const metaByFile = {};
  (e.file_meta || []).forEach((m) => { metaByFile[m.file] = m; });
  $("fileList").innerHTML = e.files.length
    ? e.files.map((f) => {
        const m = metaByFile[f];
        const metaTxt = m ? `<span class="meta">· ${m.parts > 1 ? `part${m.part}` : nf.format(m.chunk_rows) + "건"} · ${m.elapsed}s</span>` : "";
        return `<a class="file-chip" href="/api/jobs/${currentJob}/download/${encodeURIComponent(f)}">${dlIcon}<span>${f}</span>${metaTxt}</a>`;
      }).join("")
    : `<p class="hint">생성된 파일이 없습니다.</p>`;

  const standard = c.standard !== false;
  document.querySelector(".charts").style.display = standard ? "" : "none";
  document.querySelector(".pivot").style.display = standard ? "" : "none";
  let note = document.getElementById("nonStdNote");
  if (!standard) {
    if (!note) {
      note = document.createElement("div");
      note.id = "nonStdNote"; note.className = "callout-note";
      document.querySelector(".files").after(note);
    }
    note.textContent = "표준 매출 컬럼이 아니어서 차트·피벗은 생략했습니다. CSV·엑셀·미리보기는 정상입니다.";
    note.style.display = "";
  } else if (note) {
    note.style.display = "none";
  }

  if (standard) { drawCharts(c); }
  drawPreview(c);
  $("results").hidden = false;
  $("results").scrollIntoView({ behavior: "smooth", block: "start" });
}
function statCard(k, v, unit, accent) {
  return `<div class="stat${accent ? " stat--accent" : ""}"><div class="stat__k">${k}</div>
    <div class="stat__v">${v}${unit ? `<small>${unit}</small>` : ""}</div></div>`;
}

/* ── 차트 ─────────────────────────────────────── */
const COBALT = "#2f4fe0", gridColor = "rgba(20,26,40,.06)";
Chart.defaults.font.family = "'Pretendard', sans-serif";
Chart.defaults.color = "#8b93a5";
function destroyChart(k) { if (charts[k]) { charts[k].destroy(); charts[k] = null; } }
function drawCharts(c) {
  destroyChart("date");
  charts.date = new Chart($("chartDate"), {
    type: "line",
    data: { labels: c.by_date.labels, datasets: [{ label: "실매출액", data: c.by_date.real,
      borderColor: COBALT, backgroundColor: "rgba(47,79,224,.10)", fill: true, tension: 0.3,
      pointRadius: 3, pointBackgroundColor: COBALT, borderWidth: 2 }] },
    options: baseOpts({ money: true }),
  });
  destroyChart("store");
  charts.store = new Chart($("chartStore"), {
    type: "bar",
    data: { labels: c.top_stores.labels, datasets: [{ label: "실매출액", data: c.top_stores.real, backgroundColor: COBALT, borderRadius: 4 }] },
    options: baseOpts({ money: true, horizontal: true }),
  });
  destroyChart("product");
  charts.product = new Chart($("chartProduct"), {
    type: "bar",
    data: { labels: c.top_products.labels, datasets: [{ label: "판매수량", data: c.top_products.qty, backgroundColor: "#5e79ff", borderRadius: 4 }] },
    options: baseOpts({ horizontal: true }),
  });
}
function baseOpts({ money = false, horizontal = false } = {}) {
  const fmtVal = (v) => (money ? won(v) : nf.format(v));
  return {
    indexAxis: horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false },
      tooltip: { callbacks: { label: (ctx) => "  " + fmtVal(ctx.parsed[horizontal ? "x" : "y"]) } } },
    scales: {
      x: { grid: { color: gridColor }, ticks: { callback: horizontal ? (v) => (money ? "₩" + short(v) : nf.format(v)) : undefined } },
      y: { grid: { color: gridColor }, ticks: { callback: horizontal ? undefined : (v) => (money ? "₩" + short(v) : nf.format(v)) } },
    },
  };
}
function short(v) {
  if (v >= 1e8) return (v / 1e8).toFixed(1) + "억";
  if (v >= 1e4) return (v / 1e4).toFixed(0) + "만";
  return nf.format(v);
}

/* ── 미리보기 테이블 ──────────────────────────── */
function drawPreview(c) {
  const cols = c.columns;
  const numNames = new Set(["판매수량", "총매출액", "실매출액"]);
  const numeric = new Set(cols.map((h, i) => (numNames.has(h) ? i : -1)).filter((i) => i >= 0));
  const head = `<thead><tr>${cols.map((h) => `<th>${h}</th>`).join("")}</tr></thead>`;
  const rows = c.preview.map((r) =>
    `<tr>${r.map((cell, i) => `<td class="${numeric.has(i) ? "num" : ""}">${numeric.has(i) ? nf.format(cell) : cell}</td>`).join("")}</tr>`
  ).join("");
  $("previewTable").innerHTML = head + `<tbody>${rows}</tbody>`;
}

/* ── 도움말 패널 ──────────────────────────────── */
(function initHelp() {
  const toc = $("helpToc");
  document.querySelectorAll(".help-sec").forEach((sec) => {
    const h = sec.querySelector("h3");
    if (!h) return;
    const a = document.createElement("a");
    a.href = "#" + sec.id;
    a.textContent = h.textContent.replace(/^\d+\.\s*/, "");
    a.addEventListener("click", (e) => {
      e.preventDefault();
      sec.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    toc.appendChild(a);
  });
})();
function openHelp() { $("helpOverlay").hidden = false; $("helpPanel").hidden = false; }
function closeHelp() { $("helpOverlay").hidden = true; $("helpPanel").hidden = true; }
$("btnHelp").addEventListener("click", openHelp);
$("btnHelpClose").addEventListener("click", closeHelp);
$("helpOverlay").addEventListener("click", closeHelp);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeHelp(); });

/* ── 다크 모드 ────────────────────────────────── */
(function initTheme() {
  // 저장소 없이 동작: OS 선호 + 세션 변수만
  const prefDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  if (prefDark) applyTheme(true);
  $("btnTheme").addEventListener("click", () => applyTheme(!document.body.classList.contains("dark")));
})();
function applyTheme(dark) {
  document.body.classList.toggle("dark", dark);
  $("themeIcon").textContent = dark ? "☀️" : "🌙";
}

/* ── 쿼리 검증 ────────────────────────────────── */
$("btnValidate").addEventListener("click", async () => {
  setEst("검증 중…", "");
  try {
    const r = await fetch("/api/validate-query", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(collectConfig()),
    });
    const d = await r.json();
    setEst(d.message, d.ok ? "ok" : "fail");
  } catch (e) { setEst("검증 요청 실패: " + e.message, "fail"); }
});

/* ── 예상 건수·시간 ───────────────────────────── */
$("btnEstimate").addEventListener("click", async () => {
  setEst("첫 구간을 시범 조회해 추정 중…", "");
  try {
    const r = await fetch("/api/estimate", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(collectConfig()),
    });
    const d = await r.json();
    if (!d.ok) { setEst(d.message || "추정 실패", "fail"); return; }
    const m = Math.floor(d.est_total_sec / 60), s = Math.round(d.est_total_sec % 60);
    const tstr = m > 0 ? `${m}분 ${s}초` : `${s}초`;
    setEst(`첫 구간 <b>${nf.format(d.first_rows)}</b>건/<b>${d.first_sec}</b>s · ` +
           `전체 ${d.task_count}구간 예상 약 <b>${nf.format(d.est_total_rows)}</b>건 · <b>${tstr}</b>`, "ok");
  } catch (e) { setEst("추정 요청 실패: " + e.message, "fail"); }
});
function setEst(html, state) { const el = $("estResult"); el.innerHTML = html; el.dataset.state = state || ""; }

/* ── 두레이 테스트 ────────────────────────────── */
$("doorayPreset").addEventListener("change", (e) => {
  const url = e.target.value;
  if (url) {
    $("doorayWebhook").value = url;      // 선택하면 입력칸에 채움 (이후 직접 수정 가능)
    $("doorayEnabled").checked = true;   // 채널을 고르면 알림도 자동으로 켬
  }
});
// 직접 URL을 수정하면, 프리셋 목록과 다를 경우 드롭다운을 '직접 입력'으로
$("doorayWebhook").addEventListener("input", () => {
  const sel = $("doorayPreset");
  const match = [...sel.options].some((o) => o.value === $("doorayWebhook").value);
  if (!match) sel.value = "";
});
$("btnTestDooray").addEventListener("click", async () => {
  const url = $("doorayWebhook").value.trim();
  const msg = $("doorayMsg");
  if (!url) { msg.textContent = "URL을 먼저 입력하세요."; msg.dataset.state = "fail"; return; }
  msg.textContent = "전송 중…"; msg.dataset.state = "";
  try {
    const r = await fetch("/api/test-dooray", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ webhook: url }),
    });
    const d = await r.json();
    msg.textContent = d.message; msg.dataset.state = d.ok ? "ok" : "fail";
  } catch (e) { msg.textContent = "실패: " + e.message; msg.dataset.state = "fail"; }
});

/* ── 완료 알림 (팝업/소리) ────────────────────── */
function notifyDone(e) {
  // 소리
  if ($("notifySound").checked) {
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator(), g = ac.createGain();
      o.connect(g); g.connect(ac.destination);
      o.type = "sine"; o.frequency.value = 880;
      g.gain.setValueAtTime(0.001, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.2, ac.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.5);
      o.start(); o.stop(ac.currentTime + 0.5);
    } catch { /* 무시 */ }
  }
  // 브라우저 팝업 알림
  if ($("notifyBrowser").checked && "Notification" in window) {
    const body = `총 ${nf.format(e.total_rows)}건 · 파일 ${e.file_count}개 · ${e.elapsed}s`;
    const show = () => { try { new Notification("추출 완료", { body }); } catch {} };
    if (Notification.permission === "granted") show();
    else if (Notification.permission !== "denied") Notification.requestPermission().then((p) => { if (p === "granted") show(); });
  }
}

/* ── ZIP / 엑셀 ───────────────────────────────── */
$("btnZip").addEventListener("click", () => { if (currentJob) window.location.href = `/api/jobs/${currentJob}/download-zip`; });
$("btnXlsx").addEventListener("click", () => { if (currentJob) window.location.href = `/api/jobs/${currentJob}/download-xlsx`; });
$("btnOpenFolder").addEventListener("click", async () => {
  if (!currentJob) return;
  const r = await fetch(`/api/jobs/${currentJob}/open-folder`, { method: "POST" });
  const d = await r.json();
  if (!d.ok) alert("폴더를 자동으로 열지 못했습니다. 아래 경로를 탐색기에 붙여넣으세요:\n\n" + (d.path || ""));
});

/* ── 이메일 발송 로그 표시 ────────────────────── */
const _origHandle = handleEvent;
handleEvent = function (e) {
  if (e.type === "log" && e.level === "mail") { logLine("ok", `✉ ${e.msg}`); return; }
  if (e.type === "log" && e.level === "retry") { logLine("error", `    ↻ ${e.msg}`); return; }
  if (e.type === "done") { _origHandle(e); loadHistory(); notifyDone(e); return; }
  _origHandle(e);
};

/* ── 자격증명 (OS 저장소) ─────────────────────── */
async function loadCredentials() {
  try {
    const r = await fetch("/api/credentials");
    if (!r.ok) return;
    const d = await r.json();
    $("credSelect").innerHTML = `<option value="">저장된 접속 불러오기…</option>` +
      (d.labels || []).map((l) => `<option value="${l}">${l}</option>`).join("");
  } catch { /* keyring 미설치 등 — 조용히 무시 */ }
}
$("btnCredSave").addEventListener("click", async () => {
  const label = prompt("이 접속 정보를 어떤 이름으로 저장할까요? (예: 운영DB)");
  if (!label) return;
  const r = await fetch("/api/credentials", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ label: label.trim(), db_user: $("dbUser").value.trim(),
      db_dsn: $("dbDsn").value.trim(), db_password: $("dbPassword").value }),
  });
  if (r.ok) { await loadCredentials(); $("credSelect").value = label.trim(); }
  else alert("저장 실패 — keyring 설치가 필요할 수 있습니다. (pip install keyring)");
});
$("credSelect").addEventListener("change", async (e) => {
  const label = e.target.value; if (!label) return;
  const r = await fetch(`/api/credentials/${encodeURIComponent(label)}`);
  if (!r.ok) return;
  const d = await r.json();
  $("dbUser").value = d.db_user || ""; $("dbDsn").value = d.db_dsn || ""; $("dbPassword").value = d.db_password || "";
  setConnMsg(`'${label}' 접속 정보를 불러왔습니다.`, "ok");
});
$("btnCredDelete").addEventListener("click", async () => {
  const label = $("credSelect").value; if (!label) return;
  if (!confirm(`'${label}' 자격증명을 삭제할까요?`)) return;
  await fetch(`/api/credentials/${encodeURIComponent(label)}`, { method: "DELETE" });
  await loadCredentials();
});
loadCredentials();

/* ── 추출 이력 ────────────────────────────────── */
async function loadHistory() {
  try {
    const r = await fetch("/api/history");
    const d = await r.json();
    const box = $("historyList");
    if (!d.items.length) { box.innerHTML = `<p class="hint">완료된 추출이 여기에 기록됩니다.</p>`; return; }
    box.innerHTML = d.items.map((h, i) => `
      <div class="hist">
        <div class="hist__main">
          <span class="hist__time mono">${h.time}</span>
          <span class="hist__sum">${h.split_summary}${h.demo ? " · 데모" : ""}</span>
          <span class="hist__stat mono">${nf.format(h.total_rows)}건 · ${h.file_count}파일 · ${h.task_count}구간 · ${h.elapsed}s</span>
        </div>
        <button class="btn btn--ghost btn--sm" data-hist="${i}">불러오기</button>
      </div>`).join("");
    box.querySelectorAll("[data-hist]").forEach((btn) =>
      btn.addEventListener("click", () => { applyConfig(d.items[+btn.dataset.hist].config); window.scrollTo({ top: 0, behavior: "smooth" }); }));
  } catch { /* 무시 */ }
}
$("btnHistClear").addEventListener("click", async () => {
  if (!confirm("추출 이력을 모두 지울까요?")) return;
  await fetch("/api/history", { method: "DELETE" });
  loadHistory();
});
loadHistory();

/* ── 예약 명령 ────────────────────────────────── */
$("btnSchedule").addEventListener("click", async () => {
  const preset = $("presetSelect").value;
  if (!preset) { alert("먼저 위에서 저장된 작업을 선택하세요. (예약은 저장된 작업 기준으로 동작합니다)"); return; }
  const time = prompt("매일 몇 시에 실행할까요? (HH:MM)", "07:00");
  if (!time) return;
  const r = await fetch(`/api/schedule-command?preset=${encodeURIComponent(preset)}&time_hhmm=${encodeURIComponent(time)}`);
  const d = await r.json();
  $("schedText").textContent = d.command;
  $("schedNote").textContent = d.note;
  $("schedModal").hidden = false;
});
$("btnSchedClose").addEventListener("click", () => { $("schedModal").hidden = true; });
$("schedModal").addEventListener("click", (e) => { if (e.target === $("schedModal")) $("schedModal").hidden = true; });

/* ESC 키로 열린 모달 닫기 */
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    $("queryModal").hidden = true;
    $("schedModal").hidden = true;
  }
});

/* ── 피벗 대시보드 ────────────────────────────── */
let pivotChart = null;
let pivotTimer = null;
async function refreshPivot() {
  if (!currentJob) return;
  const row = $("pivotRow").value, metric = $("pivotMetric").value, q = $("pivotSearch").value.trim();
  const r = await fetch(`/api/jobs/${currentJob}/pivot?row=${row}&metric=${metric}&q=${encodeURIComponent(q)}`);
  if (!r.ok) return;
  const d = await r.json();
  if (d.standard === false) {
    if (pivotChart) { pivotChart.destroy(); pivotChart = null; }
    $("pivotTable").innerHTML = `<tbody><tr><td class="hint" style="padding:14px">표준 매출 컬럼이 아니어서 피벗을 만들 수 없습니다.</td></tr></tbody>`;
    return;
  }
  const isMoney = metric !== "qty";
  const fmt = (v) => (isMoney ? won(v) : nf.format(v));

  // 차트 (상위 15)
  const N = 15;
  const labels = d.labels.slice(0, N), values = d.values.slice(0, N);
  if (pivotChart) pivotChart.destroy();
  pivotChart = new Chart($("pivotChart"), {
    type: "bar",
    data: { labels, datasets: [{ data: values, backgroundColor: "#2f4fe0", borderRadius: 4 }] },
    options: baseOpts({ money: isMoney, horizontal: true }),
  });

  // 표
  const metricName = { real: "실매출액", tot: "총매출액", qty: "판매수량" }[metric];
  const head = `<thead><tr><th>${{store:"매장",product:"상품",date:"일자"}[row]}</th><th class="ta-r">${metricName}</th><th class="ta-r">건수</th></tr></thead>`;
  const body = d.labels.map((l, i) =>
    `<tr><td>${l}</td><td class="num">${fmt(d.values[i])}</td><td class="num">${nf.format(d.counts[i])}</td></tr>`).join("");
  $("pivotTable").innerHTML = head + `<tbody>${body}</tbody>`;
}
["pivotRow", "pivotMetric"].forEach((id) => $(id).addEventListener("change", refreshPivot));
$("pivotSearch").addEventListener("input", () => { clearTimeout(pivotTimer); pivotTimer = setTimeout(refreshPivot, 250); });

/* 결과가 렌더될 때 피벗도 초기화 */
const _origRender = renderResults;
renderResults = function (e) { _origRender(e); refreshPivot(); };
