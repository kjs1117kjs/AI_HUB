"""
xlsx_merge.py — 구간별 CSV 여러 개를 엑셀 하나로 병합

시트 구성
  - 요약    : 일자별 / 매장별 / 상품별 집계 (실매출 기준 정렬)
  - 전체데이터 : 모든 CSV를 이어붙인 원본 (구간 컬럼 추가), 자동필터 + 틀고정

openpyxl 사용. main.py 와 run_preset.py 에서 공통으로 호출한다.
"""

from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

COLUMNS = ["매출일자", "매장코드", "매장명", "상품명", "판매수량", "총매출액", "실매출액"]
NUM_COLS = {4, 5, 6}   # 판매수량, 총매출액, 실매출액

HEAD_FILL = PatternFill("solid", fgColor="2F4FE0")
HEAD_FONT = Font(color="FFFFFF", bold=True, size=11)
TITLE_FONT = Font(bold=True, size=13, color="161A22")
SUB_FILL = PatternFill("solid", fgColor="EEF0F4")
THIN = Side(style="thin", color="D2D6E0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def _read_csv(path: Path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.reader(f)
        rows = list(r)
    return rows[0], rows[1:]   # header, data


def _num(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _style_header(ws, ncols, row=1):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEAD_FILL; cell.font = HEAD_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER


def merge_to_xlsx(csv_paths, out_path):
    csv_paths = [Path(p) for p in csv_paths]
    wb = Workbook()

    # 컬럼 파악 (첫 CSV 헤더)
    header0, _ = _read_csv(csv_paths[0]) if csv_paths else (COLUMNS, [])
    pos = {name: i for i, name in enumerate(header0)}
    std = all(name in pos for name in COLUMNS)
    ncols = len(header0)

    # ── 시트: 전체데이터 (어떤 쿼리든 동작) ──
    ws = wb.active
    ws.title = "전체데이터"
    ws.append(["구간"] + header0)

    by_date, by_store, by_product = {}, {}, {}
    total_rows = 0
    for path in csv_paths:
        seg = path.stem
        _, data = _read_csv(path)
        for row in data:
            ws.append([seg] + row)
            total_rows += 1
            if std:
                qty = _num(row[pos["판매수량"]]); tot = _num(row[pos["총매출액"]]); real = _num(row[pos["실매출액"]])
                d = by_date.setdefault(row[pos["매출일자"]], [0.0,0.0,0.0]); d[0]+=qty; d[1]+=tot; d[2]+=real
                s = by_store.setdefault(row[pos["매장명"]], [0.0,0.0,0.0]); s[0]+=qty; s[1]+=tot; s[2]+=real
                by_product[row[pos["상품명"]]] = by_product.get(row[pos["상품명"]], 0.0) + qty

    _style_header(ws, ncols + 1)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ncols + 1)}{ws.max_row}"
    for i in range(1, ncols + 2):
        ws.column_dimensions[get_column_letter(i)].width = 16

    # ── 시트: 요약 (표준 컬럼일 때만) ──
    if std:
        sm = wb.create_sheet("요약", 0)
        sm.append(["추출 요약"]); sm["A1"].font = TITLE_FONT
        sm.append([f"총 {total_rows:,} 건 · 파일 {len(csv_paths)} 개 병합"])
        sm.append([])

        def block(title, header, items, start_row):
            sm.cell(row=start_row, column=1, value=title).font = Font(bold=True, size=12)
            r = start_row + 1
            for j, h in enumerate(header, 1):
                cell = sm.cell(row=r, column=j, value=h)
                cell.fill = HEAD_FILL; cell.font = HEAD_FONT
                cell.alignment = Alignment(horizontal="center")
            r += 1
            for name, vals in items:
                sm.cell(row=r, column=1, value=name)
                for j, v in enumerate(vals, 2):
                    cell = sm.cell(row=r, column=j, value=round(v)); cell.number_format = "#,##0"
                r += 1
            return r + 1

        nxt = block("■ 일자별", ["매출일자", "판매수량", "총매출액", "실매출액"],
                    sorted(([k, v] for k, v in by_date.items())), 4)
        top_store = sorted(by_store.items(), key=lambda kv: kv[1][2], reverse=True)[:30]
        nxt = block("■ 매장별 (실매출 상위 30)", ["매장명", "판매수량", "총매출액", "실매출액"], top_store, nxt)
        top_prod = sorted(by_product.items(), key=lambda kv: kv[1], reverse=True)[:30]
        block("■ 상품별 (수량 상위 30)", ["상품명", "판매수량"], [[k, [v]] for k, v in top_prod], nxt)
        for col, w in zip("ABCD", [26, 14, 14, 14]):
            sm.column_dimensions[col].width = w

    wb.save(out_path)
    return out_path
