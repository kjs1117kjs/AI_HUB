"""
main.py — Oracle 매출 추출기 FastAPI 백엔드 (전체 기능판)

기능: 다차원 분할 추출 · 실시간 로그(SSE) · 프리셋 저장 · 추출 이력 ·
      엑셀 병합 · 이메일 발송 · 자격증명 저장(keyring) · 피벗 대시보드 ·
      예약 실행 명령 생성

실행: uvicorn main:app --reload --port 8000  → http://127.0.0.1:8000
"""

from __future__ import annotations

import io
import json
import queue
import smtplib
import threading
import time
import uuid
import zipfile
from email.message import EmailMessage
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import extractor as ex

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = BASE_DIR / "output"
OUTPUT_ROOT.mkdir(exist_ok=True)
PRESET_FILE = BASE_DIR / "presets.json"
HISTORY_FILE = BASE_DIR / "history.json"
KEYRING_SERVICE = "oracle_extractor"

app = FastAPI(title="Oracle 매출 추출기")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


# ─────────────────────────────────────────────
# 요청 모델
# ─────────────────────────────────────────────
class SplitIn(BaseModel):
    type: str = "date"
    column: str = "tsdps.SALE_DATE"
    start: str = ""
    end: str = ""
    step: int = 3
    pad: int = 0
    values: list[str] = []
    batch: int = 10


class EmailIn(BaseModel):
    enabled: bool = False
    host: str = ""
    port: int = 587
    user: str = ""
    password: str = ""
    to: str = ""
    subject: str = "매출 추출 결과"
    as_xlsx: bool = True


class ConfigIn(BaseModel):
    db_user: str = ""
    db_password: str = ""
    db_dsn: str = ""
    office_cd: str = "H0393"
    brand_codes: list[str] = ["100", "101", "102", "114"]
    splits: list[SplitIn] = []
    sleep_sec: float = 1.0
    arraysize: int = 5000
    save_empty: bool = False
    demo: bool = False
    max_retries: int = 1
    retry_delay: float = 2.0
    parallel: int = 1
    query_mode: str = "auto"
    custom_query: str = ""
    apply_split: bool = True
    max_rows_per_file: int = 0
    dooray_webhook: str = ""     # 완료 시 두레이(Incoming Webhook)로 알림
    email: EmailIn = EmailIn()

    def to_cfg(self) -> ex.ExtractConfig:
        data = self.model_dump()
        data.pop("email", None)
        data.pop("dooray_webhook", None)
        splits = [ex.SplitDim(**s) for s in data.pop("splits")]
        return ex.ExtractConfig(splits=splits, **data)


# ─────────────────────────────────────────────
# 작업(Job)
# ─────────────────────────────────────────────
class Job:
    def __init__(self, cfg: ex.ExtractConfig, email: dict, raw_cfg: dict, dooray: str = ""):
        self.id = uuid.uuid4().hex[:12]
        self.cfg = cfg
        self.email = email
        self.dooray = dooray
        self.raw_cfg = raw_cfg
        self.out_dir = OUTPUT_ROOT / self.id
        self.queue: "queue.Queue[dict]" = queue.Queue()
        self.cancel_flag = threading.Event()
        self.done = False
        self.result: dict | None = None
        self.started = time.time()

    def emit(self, event: dict):
        self.queue.put(event)

    def run(self):
        try:
            self.result = ex.run_extraction(
                self.cfg, str(self.out_dir), emit=self.emit, cancel=self.cancel_flag.is_set)
            _record_history(self)
            if self.dooray and self.result:
                self._notify_dooray()
            if self.email.get("enabled") and self.result and self.result["file_count"]:
                self._send_email()
        except Exception as exc:  # noqa: BLE001
            self.emit({"type": "error", "msg": str(exc)})
        finally:
            self.done = True
            self.emit({"type": "_eos"})

    def _notify_dooray(self):
        try:
            import urllib.request
            r = self.result
            text = (f"[추출 완료] {self.cfg.office_cd}\n"
                    f"총 {r['total_rows']:,}건 · 파일 {r['file_count']}개 · "
                    f"구간 {r['chunk_count']}개 · {r['elapsed']}초")
            body = json.dumps({"botName": "추출 콘솔", "text": text}).encode("utf-8")
            req = urllib.request.Request(self.dooray, data=body,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15)
            self.emit({"type": "log", "level": "mail", "msg": "두레이 알림 발송 완료"})
        except Exception as exc:  # noqa: BLE001
            self.emit({"type": "log", "level": "retry", "msg": f"두레이 알림 실패: {exc}"})

    def _send_email(self):
        try:
            attach_bytes, attach_name, mime = self._build_attachment()
            msg = EmailMessage()
            msg["Subject"] = self.email.get("subject") or "매출 추출 결과"
            msg["From"] = self.email.get("user", "")
            msg["To"] = self.email.get("to", "")
            r = self.result
            msg.set_content(
                f"추출 완료\n총 {r['total_rows']:,}건 · 파일 {r['file_count']}개 · {r['elapsed']}초")
            maintype, subtype = mime.split("/")
            msg.add_attachment(attach_bytes, maintype=maintype, subtype=subtype, filename=attach_name)
            port = int(self.email.get("port", 587))
            with smtplib.SMTP(self.email["host"], port, timeout=30) as s:
                s.starttls()
                if self.email.get("user"):
                    s.login(self.email["user"], self.email.get("password", ""))
                s.send_message(msg)
            self.emit({"type": "log", "level": "mail", "msg": f"이메일 발송 완료 → {self.email.get('to')}"})
        except Exception as exc:  # noqa: BLE001
            self.emit({"type": "log", "level": "retry", "msg": f"이메일 발송 실패: {exc}"})

    def _build_attachment(self):
        files = sorted(self.out_dir.glob("*.csv"))
        if self.email.get("as_xlsx"):
            from xlsx_merge import merge_to_xlsx
            xpath = self.out_dir / f"{self.cfg.office_cd}_{self.id}.xlsx"
            merge_to_xlsx(files, xpath)
            return xpath.read_bytes(), xpath.name, \
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in files:
                zf.write(f, arcname=f.name)
        return buf.getvalue(), f"{self.cfg.office_cd}_{self.id}.zip", "application/zip"


JOBS: dict[str, Job] = {}


# ─────────────────────────────────────────────
# 프리셋 / 이력 파일 IO
# ─────────────────────────────────────────────
def _load_json(path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return default
    return default


def _save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _split_summary(splits):
    names = {"date": "날짜", "range": "코드범위", "list": "코드목록"}
    return " × ".join(f"{names.get(s['type'], s['type'])}({s.get('column','')})" for s in splits) or "전체"


def _record_history(job: Job):
    hist = _load_json(HISTORY_FILE, [])
    cfg = dict(job.raw_cfg)
    cfg.pop("db_password", None)
    if "email" in cfg:
        cfg["email"] = {**cfg["email"], "password": ""}
    r = job.result or {}
    hist.insert(0, {
        "id": job.id,
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(job.started)),
        "office_cd": job.cfg.office_cd,
        "demo": job.cfg.demo,
        "split_summary": _split_summary(job.raw_cfg.get("splits", [])),
        "task_count": len(ex.plan_tasks(job.cfg)),
        "total_rows": r.get("total_rows", 0),
        "file_count": r.get("file_count", 0),
        "elapsed": r.get("elapsed", 0),
        "config": cfg,
    })
    _save_json(HISTORY_FILE, hist[:100])


# ─────────────────────────────────────────────
# 라우트: 기본
# ─────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE_DIR / "templates" / "index.html").read_text(encoding="utf-8")


@app.post("/api/test-connection")
def api_test_connection(cfg_in: ConfigIn):
    ok, msg = ex.test_connection(cfg_in.to_cfg())
    return {"ok": ok, "message": msg}


@app.get("/api/default-query")
def api_default_query():
    return {"query": ex.default_query()}


@app.post("/api/preview-query")
def api_preview_query(cfg_in: ConfigIn):
    try:
        return {"ok": True, **ex.preview(cfg_in.to_cfg())}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": str(exc)}


@app.post("/api/jobs")
def api_create_job(cfg_in: ConfigIn):
    cfg = cfg_in.to_cfg()
    try:
        cfg.validated_brands()
        tasks = ex.plan_tasks(cfg)
        ex.build_query(cfg, tasks[0])   # 커스텀 쿼리 {where} 누락 등 사전 검증
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=str(exc))
    job = Job(cfg, cfg_in.email.model_dump(), cfg_in.model_dump(), dooray=cfg_in.dooray_webhook)
    JOBS[job.id] = job
    threading.Thread(target=job.run, daemon=True).start()
    return {"job_id": job.id}


@app.post("/api/validate-query")
def api_validate_query(cfg_in: ConfigIn):
    return ex.validate_query(cfg_in.to_cfg())


@app.post("/api/estimate")
def api_estimate(cfg_in: ConfigIn):
    try:
        return {"ok": True, **ex.estimate(cfg_in.to_cfg())}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": str(exc)}


@app.post("/api/test-dooray")
def api_test_dooray(payload: dict):
    url = (payload or {}).get("webhook", "").strip()
    if not url:
        return {"ok": False, "message": "웹훅 URL이 비어 있습니다."}
    try:
        import urllib.request
        body = json.dumps({"botName": "추출 콘솔", "text": "테스트 메시지 — 연결 정상입니다."}).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=15)
        return {"ok": True, "message": "두레이로 테스트 메시지를 보냈습니다."}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": f"발송 실패: {exc}"}


@app.get("/api/jobs/{job_id}/stream")
def api_stream(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")

    def gen():
        while True:
            try:
                event = job.queue.get(timeout=30)
            except queue.Empty:
                yield ": keep-alive\n\n"; continue
            if event.get("type") == "_eos":
                yield f"data: {json.dumps({'type': 'end'})}\n\n"; break
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")


@app.post("/api/jobs/{job_id}/cancel")
def api_cancel(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    job.cancel_flag.set()
    return {"ok": True}


# ─────────────────────────────────────────────
# 라우트: 다운로드 (CSV / ZIP / XLSX)
# ─────────────────────────────────────────────
def _job_or_404(job_id):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    return job


@app.get("/api/jobs/{job_id}/download/{filename}")
def api_download(job_id: str, filename: str):
    job = _job_or_404(job_id)
    fpath = job.out_dir / Path(filename).name
    if not fpath.exists():
        raise HTTPException(status_code=404, detail="파일이 없습니다.")
    return FileResponse(fpath, filename=fpath.name, media_type="text/csv")


@app.get("/api/jobs/{job_id}/download-zip")
def api_download_zip(job_id: str):
    job = _job_or_404(job_id)
    files = sorted(job.out_dir.glob("*.csv"))
    if not files:
        raise HTTPException(status_code=404, detail="내려받을 파일이 없습니다.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.write(f, arcname=f.name)
    buf.seek(0)
    return Response(content=buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{job.cfg.office_cd}_{job.id}.zip"'})


@app.get("/api/jobs/{job_id}/download-xlsx")
def api_download_xlsx(job_id: str):
    job = _job_or_404(job_id)
    files = sorted(job.out_dir.glob("*.csv"))
    if not files:
        raise HTTPException(status_code=404, detail="병합할 파일이 없습니다.")
    try:
        from xlsx_merge import merge_to_xlsx
    except ImportError:
        raise HTTPException(status_code=500, detail="openpyxl 이 필요합니다. (pip install openpyxl)")
    xpath = job.out_dir / f"{job.cfg.office_cd}_{job.id}.xlsx"
    merge_to_xlsx(files, xpath)
    return FileResponse(xpath, filename=xpath.name,
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.post("/api/jobs/{job_id}/open-folder")
def api_open_folder(job_id: str):
    job = _job_or_404(job_id)
    path = job.out_dir
    path.mkdir(parents=True, exist_ok=True)
    import sys, subprocess
    try:
        if sys.platform.startswith("win"):
            import os as _os
            _os.startfile(str(path))  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
        return {"ok": True, "path": str(path)}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "path": str(path), "message": str(exc)}


@app.get("/api/jobs/{job_id}/pivot")
def api_pivot(job_id: str, row: str = "store", metric: str = "real", q: str = ""):
    job = _job_or_404(job_id)
    from pivot import pivot
    return pivot(job.out_dir, row=row, metric=metric, q=q)


# ─────────────────────────────────────────────
# 라우트: 프리셋
# ─────────────────────────────────────────────
class PresetIn(BaseModel):
    name: str
    config: dict


@app.get("/api/presets")
def api_presets_list():
    return {"names": sorted(_load_json(PRESET_FILE, {}).keys())}


@app.get("/api/presets/{name}")
def api_preset_get(name: str):
    presets = _load_json(PRESET_FILE, {})
    if name not in presets:
        raise HTTPException(status_code=404, detail="저장된 설정이 없습니다.")
    return {"name": name, "config": presets[name]}


@app.post("/api/presets")
def api_preset_save(p: PresetIn):
    name = p.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="이름을 입력하세요.")
    presets = _load_json(PRESET_FILE, {})
    cfg = dict(p.config)
    cfg.pop("db_password", None)
    if "email" in cfg and isinstance(cfg["email"], dict):
        cfg["email"] = {**cfg["email"], "password": ""}
    presets[name] = cfg
    _save_json(PRESET_FILE, presets)
    return {"ok": True, "names": sorted(presets.keys())}


@app.delete("/api/presets/{name}")
def api_preset_delete(name: str):
    presets = _load_json(PRESET_FILE, {})
    presets.pop(name, None)
    _save_json(PRESET_FILE, presets)
    return {"ok": True, "names": sorted(presets.keys())}


# ─────────────────────────────────────────────
# 라우트: 추출 이력
# ─────────────────────────────────────────────
@app.get("/api/history")
def api_history():
    return {"items": _load_json(HISTORY_FILE, [])[:50]}


@app.delete("/api/history")
def api_history_clear():
    _save_json(HISTORY_FILE, [])
    return {"ok": True}


# ─────────────────────────────────────────────
# 라우트: 자격증명 (OS 자격증명 저장소 = keyring)
# ─────────────────────────────────────────────
def _keyring():
    try:
        import keyring
        return keyring
    except ImportError:
        raise HTTPException(status_code=500,
                            detail="keyring 이 필요합니다. (pip install keyring)")


class CredIn(BaseModel):
    label: str
    db_user: str = ""
    db_dsn: str = ""
    db_password: str = ""


@app.get("/api/credentials")
def api_cred_list():
    kr = _keyring()
    index = _load_json(BASE_DIR / ".cred_index.json", [])
    return {"labels": index}


@app.post("/api/credentials")
def api_cred_save(c: CredIn):
    kr = _keyring()
    label = c.label.strip()
    if not label:
        raise HTTPException(status_code=400, detail="이름을 입력하세요.")
    blob = json.dumps({"db_user": c.db_user, "db_dsn": c.db_dsn, "db_password": c.db_password})
    kr.set_password(KEYRING_SERVICE, label, blob)
    idx_path = BASE_DIR / ".cred_index.json"
    index = _load_json(idx_path, [])
    if label not in index:
        index.append(label); _save_json(idx_path, sorted(index))
    return {"ok": True, "labels": sorted(index)}


@app.get("/api/credentials/{label}")
def api_cred_get(label: str):
    kr = _keyring()
    blob = kr.get_password(KEYRING_SERVICE, label)
    if not blob:
        raise HTTPException(status_code=404, detail="저장된 자격증명이 없습니다.")
    return {"label": label, **json.loads(blob)}


@app.delete("/api/credentials/{label}")
def api_cred_delete(label: str):
    kr = _keyring()
    try:
        kr.delete_password(KEYRING_SERVICE, label)
    except Exception:  # noqa: BLE001
        pass
    idx_path = BASE_DIR / ".cred_index.json"
    index = [x for x in _load_json(idx_path, []) if x != label]
    _save_json(idx_path, index)
    return {"ok": True, "labels": index}


# ─────────────────────────────────────────────
# 라우트: 예약 실행 명령 생성
# ─────────────────────────────────────────────
@app.get("/api/schedule-command")
def api_schedule_command(preset: str, time_hhmm: str = "07:00", daily: bool = True, xlsx: bool = True):
    py = "python"
    script = BASE_DIR / "run_preset.py"
    xl = " --xlsx" if xlsx else ""
    inner = f'cmd /c cd /d "{BASE_DIR}" ^& {py} "{script.name}" "{preset}"{xl}'
    freq = "DAILY" if daily else "WEEKLY"
    cmd = f'schtasks /Create /TN "매출추출_{preset}" /TR "{inner}" /SC {freq} /ST {time_hhmm} /F'
    note = ("작업 스케줄러에 등록하는 명령입니다. 관리자 명령프롬프트에 붙여넣어 실행하세요. "
            "실제 DB조회 예약은 비밀번호가 필요하므로, 자동실행 계정 환경변수 ORA_PW 를 설정하거나 "
            "데모 프리셋에만 사용하세요.")
    return {"command": cmd, "note": note}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
