# -*- coding: utf-8 -*-
"""
geoip_console.py — GeoIP 재적재 웹 콘솔 (버튼 클릭 + 실시간 로그)

실행:
    cd E:\\_work\\GeoLite2
    python geoip_console.py
    → 브라우저가 자동으로 http://127.0.0.1:8765 를 엽니다.

특징:
    - 단계별 버튼: ① 다운로드 → ② 변환·검증 → ③ DB 적재 → ④ 검증·통계 → ⑤ 시노님 스위치
    - [전체 실행]은 ①~④까지만 자동 진행. 스위치(⑤)는 항상 사람이 버튼으로 확정.
    - 각 단계 상태 배지 + 하단 터미널 로그 실시간 표시.
    - 스위치 후에는 [롤백] 버튼 활성화 (이전 테이블로 즉시 원복).
    - 127.0.0.1 전용 바인딩 — 본인 PC에서만 접속 가능.

사전 준비: geoip_reload.py 와 동일 (pip install oracledb requests + geoip_config.json)
"""

import datetime
import io
import ipaddress
import json
import os
import sys
import threading
import time
import webbrowser
import zipfile
from bisect import bisect_right
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 8765

# ============================================================ 상태

STEPS = ["download", "prepare", "load", "verify", "switch"]

STATE = {
    "steps": {s: "idle" for s in STEPS},   # idle | running | ok | fail
    "log": [],                              # [세션 로그 라인]
    "busy": False,
    "use_local_csv": False,
    "active": None, "standby": None,
    "old_cnt": None, "new_cnt": None,
    "switched": False, "prev_active": None,
    "rows": None, "blocks_txt": None, "locs_txt": None,   # 단계 간 전달 (log에는 미노출)
}
LOCK = threading.Lock()


class GateError(Exception):
    pass


def log(msg, kind="info"):
    line = {"t": datetime.datetime.now().strftime("%H:%M:%S"), "m": str(msg), "k": kind}
    with LOCK:
        STATE["log"].append(line)


def set_step(step, status):
    with LOCK:
        STATE["steps"][step] = status


def save_logfile(status):
    d = os.path.join(CFG["work_dir"], "logs")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, f"console_{datetime.datetime.now():%Y%m%d_%H%M%S}_{status}.log")
    with open(p, "w", encoding="utf-8") as f:
        for ln in STATE["log"]:
            f.write(f"[{ln['t']}] {ln['m']}\n")
    log(f"로그 저장: {p}")

# ============================================================ 설정

def load_config():
    with open(os.path.join(HERE, "geoip_config.json"), encoding="utf-8") as f:
        cfg = json.load(f)
    if cfg.get("db_password") == "ENV":
        cfg["db_password"] = os.environ.get("GEOIP_DB_PASSWORD", "")
    cfg.setdefault("min_rows", 300000)
    cfg.setdefault("work_dir", HERE)
    return cfg


CFG = None

# ============================================================ 단계 구현

DL_URL = ("https://download.maxmind.com/app/geoip_download"
          "?edition_id=GeoLite2-Country-CSV&license_key={key}&suffix=zip")


def step_download():
    if STATE["use_local_csv"]:
        log("① 다운로드 생략 — 폴더의 기존 CSV 사용")
        def rd(name):
            p = os.path.join(CFG["work_dir"], name)
            if not os.path.exists(p):
                raise GateError(f"{name} 없음 — zip 압축을 풀어 이 폴더에 두거나, 옵션을 끄고 다운로드하세요")
            return open(p, encoding="utf-8").read()
        STATE["blocks_txt"] = rd("GeoLite2-Country-Blocks-IPv4.csv")
        STATE["locs_txt"]   = rd("GeoLite2-Country-Locations-en.csv")
        log("   Blocks-IPv4 / Locations-en 확보 (로컬)")
        return
    import requests
    log("① MaxMind GeoLite2-Country-CSV 다운로드 시작...")
    r = requests.get(DL_URL.format(key=CFG["license_key"]), timeout=300)
    if r.status_code != 200:
        raise GateError(f"다운로드 실패 HTTP {r.status_code} — 라이선스 키/네트워크 확인")
    zp = os.path.join(CFG["work_dir"], "GeoLite2-Country-CSV.zip")
    with open(zp, "wb") as f:
        f.write(r.content)
    log(f"   zip 저장 ({len(r.content):,} bytes)")
    blocks = locs = None
    with zipfile.ZipFile(zp) as z:
        for n in z.namelist():
            b = os.path.basename(n)
            if b == "GeoLite2-Country-Blocks-IPv4.csv":
                blocks = z.read(n).decode("utf-8")
            elif b == "GeoLite2-Country-Locations-en.csv":
                locs = z.read(n).decode("utf-8")
    if not blocks or not locs:
        raise GateError("zip 안에 Blocks-IPv4 / Locations-en CSV 없음 — 에디션 확인")
    STATE["blocks_txt"], STATE["locs_txt"] = blocks, locs
    log("   압축 해제 · CSV 확보 완료")


def step_prepare():
    import csv as csvmod
    if not STATE["blocks_txt"]:
        raise GateError("① 다운로드를 먼저 실행하세요")
    log("② CIDR → 숫자 변환 + 국가 조인...")
    loc = {}
    for r in csvmod.DictReader(io.StringIO(STATE["locs_txt"])):
        loc[r["geoname_id"]] = (r["country_iso_code"], r["country_name"])
    rows = []
    for r in csvmod.DictReader(io.StringIO(STATE["blocks_txt"])):
        gid = r["geoname_id"] or r["registered_country_geoname_id"]
        if not gid or gid not in loc:
            continue
        net = ipaddress.ip_network(r["network"])
        cc, cn = loc[gid]
        rows.append((r["network"], int(net.network_address),
                     int(net.broadcast_address), cc, cn))
    rows.sort(key=lambda x: x[1])
    log(f"   변환 완료: {len(rows):,}건")
    if len(rows) < CFG["min_rows"]:
        raise GateError(f"G1 실패 — 변환 건수 {len(rows):,} < 하한 {CFG['min_rows']:,}")
    log(f"   G1 통과 (건수 하한 {CFG['min_rows']:,})", "ok")
    starts = [x[1] for x in rows]
    def lookup(ip):
        v = int(ipaddress.ip_address(ip))
        i = bisect_right(starts, v) - 1
        return rows[i][3] if i >= 0 and rows[i][2] >= v else None
    for ip, expect in [("223.62.180.1", "KR"), ("8.8.8.8", "US")]:
        got = lookup(ip)
        if got != expect:
            raise GateError(f"G2 실패 — {ip} 기대 {expect}, 실제 {got} (데이터 이상)")
    log("   G2 통과 (샘플 IP 국가 판정: KR/US 정상)", "ok")
    STATE["rows"] = rows


def db_connect():
    import oracledb
    return oracledb.connect(user=CFG["db_user"], password=CFG["db_password"],
                            dsn=CFG["db_dsn"])


def step_load():
    if not STATE["rows"]:
        raise GateError("② 변환을 먼저 실행하세요")
    rows = STATE["rows"]
    conn = db_connect()
    try:
        cur = conn.cursor()
        cur.execute("SELECT table_name FROM user_synonyms WHERE synonym_name = 'TB_CM_GEOIP_RANGE'")
        row = cur.fetchone()
        if not row:
            raise GateError("시노님 TB_CM_GEOIP_RANGE 없음")
        active = row[0]
        standby = "TB_CM_GEOIP_RANGE_B" if active.endswith("_A") else "TB_CM_GEOIP_RANGE_A"
        STATE["active"], STATE["standby"] = active, standby
        log(f"③ 현재 활성: {active} / 대기(적재 대상): {standby}")
        log(f"   {standby} TRUNCATE 후 배치 INSERT...")
        cur.execute(f"TRUNCATE TABLE {standby}")
        sql = (f"INSERT INTO {standby} "
               "(NETWORK, START_IP_NUM, END_IP_NUM, COUNTRY_CODE, COUNTRY_NAME) "
               "VALUES (:1, :2, :3, :4, :5)")
        t0 = time.time()
        B = 20000
        for i in range(0, len(rows), B):
            cur.executemany(sql, rows[i:i+B])
            log(f"   ... {min(i+B, len(rows)):,} / {len(rows):,}")
        conn.commit()
        log(f"   적재 완료 ({time.time()-t0:.1f}s)")
        cur.execute(f"SELECT COUNT(*) FROM {standby}")
        db_cnt = cur.fetchone()[0]
        if db_cnt != len(rows):
            raise GateError(f"G3 실패 — DB {db_cnt:,} != CSV {len(rows):,}")
        STATE["new_cnt"] = db_cnt
        log(f"   G3 통과 (DB 건수 일치: {db_cnt:,})", "ok")
    finally:
        conn.close()


def step_verify():
    if not STATE["standby"] or not STATE["new_cnt"]:
        raise GateError("③ DB 적재를 먼저 실행하세요")
    active, standby, new_cnt = STATE["active"], STATE["standby"], STATE["new_cnt"]
    conn = db_connect()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT COUNT(*) FROM {active}")
        old_cnt = cur.fetchone()[0]
        STATE["old_cnt"] = old_cnt
        if old_cnt > 0 and new_cnt < old_cnt * 0.9:
            raise GateError(f"G4 실패 — 신규 {new_cnt:,} < 기존 {old_cnt:,} × 0.9")
        log(f"④ G4 통과 (기존 {old_cnt:,} → 신규 {new_cnt:,})", "ok")
        log(f"   DBMS_STATS 수집: {standby} ...")
        cur.callproc("DBMS_STATS.GATHER_TABLE_STATS",
                     keyword_parameters={"ownname": CFG["db_user"].upper(),
                                         "tabname": standby, "cascade": True})
        log("   통계수집 완료")
        q = (f"SELECT country_code FROM ("
             f"  SELECT country_code, end_ip_num FROM {standby}"
             f"  WHERE start_ip_num <= :v ORDER BY start_ip_num DESC"
             f") WHERE ROWNUM = 1 AND end_ip_num >= :v")
        for ip, expect in [("223.62.180.1", "KR"), ("8.8.8.8", "US")]:
            v = int(ipaddress.ip_address(ip))
            t0 = time.time()
            cur.execute(q, v=v)
            row = cur.fetchone()
            el = time.time() - t0
            got = row[0] if row else None
            if got != expect:
                raise GateError(f"G5 실패 — {standby}에서 {ip} 기대 {expect}, 실제 {got}")
            if el > 0.5:
                raise GateError(f"G5 실패 — {ip} 조회 {el:.2f}s (>0.5s, 통계/인덱스 확인)")
            log(f"   G5 {ip} → {got} ({el*1000:.0f}ms) OK", "ok")
        log(f"게이트 전부 통과 — 스위치 준비 완료: {active} ({old_cnt:,}) → {standby} ({new_cnt:,})", "ok")
    finally:
        conn.close()


def step_switch():
    if STATE["steps"]["verify"] != "ok":
        raise GateError("④ 검증·통계를 먼저 통과해야 스위치할 수 있습니다")
    active, standby = STATE["active"], STATE["standby"]
    conn = db_connect()
    try:
        cur = conn.cursor()
        cur.execute(f"CREATE OR REPLACE SYNONYM TB_CM_GEOIP_RANGE FOR {standby}")
        log(f"⑤ 시노님 스위치 완료 → {standby}", "ok")
        cur.execute("SELECT COUNT(*) FROM TB_CM_GEOIP_RANGE")
        log(f"   시노님 경유 건수: {cur.fetchone()[0]:,}")
        cur.execute("SELECT IS_KOREA_IP('223.62.180.1'), IS_KOREA_IP('8.8.8.8') FROM DUAL")
        kr, us = cur.fetchone()
        if kr != "Y" or us != "N":
            log(f"   ⚠ 스위치 후 판정 이상 (KR={kr}, 8.8.8.8={us}) — 롤백 버튼으로 즉시 원복하세요!", "fail")
        else:
            log("   IS_KOREA_IP 동작 확인 (KR=Y / 8.8.8.8=N)", "ok")
        STATE["switched"] = True
        STATE["prev_active"] = active
        log(f"   문제 시 [롤백] 버튼 → {active} 로 즉시 원복 가능")
        save_logfile("OK")
    finally:
        conn.close()


def step_rollback():
    prev = STATE["prev_active"]
    if not STATE["switched"] or not prev:
        raise GateError("이번 세션에 스위치한 이력이 없습니다")
    conn = db_connect()
    try:
        cur = conn.cursor()
        cur.execute(f"CREATE OR REPLACE SYNONYM TB_CM_GEOIP_RANGE FOR {prev}")
        log(f"롤백 완료 — 시노님이 {prev} 로 원복되었습니다", "ok")
        STATE["switched"] = False
        save_logfile("ROLLBACK")
    finally:
        conn.close()

# ============================================================ 실행 워커

STEP_FN = {"download": step_download, "prepare": step_prepare, "load": step_load,
           "verify": step_verify, "switch": step_switch}


def run_steps(steps):
    with LOCK:
        if STATE["busy"]:
            return
        STATE["busy"] = True
    try:
        for s in steps:
            set_step(s, "running")
            try:
                STEP_FN[s]()
                set_step(s, "ok")
            except GateError as e:
                set_step(s, "fail")
                log(f"■ 중단: {e}", "fail")
                log("■ 시노님은 변경되지 않았습니다. 서비스는 기존 테이블로 정상 동작합니다."
                    if s != "switch" else "■ 스위치 단계 오류 — 로그를 확인하세요.", "fail")
                save_logfile("FAIL")
                return
            except Exception as e:
                set_step(s, "fail")
                log(f"■ 예상치 못한 오류: {e!r}", "fail")
                save_logfile("FAIL")
                return
    finally:
        with LOCK:
            STATE["busy"] = False


def run_rollback():
    with LOCK:
        if STATE["busy"]:
            return
        STATE["busy"] = True
    try:
        step_rollback()
    except GateError as e:
        log(f"■ 롤백 불가: {e}", "fail")
    except Exception as e:
        log(f"■ 롤백 오류: {e!r}", "fail")
    finally:
        with LOCK:
            STATE["busy"] = False

# ============================================================ HTML

PAGE = """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GeoIP 재적재 콘솔</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --paper:#F2F4F3;--card:#fff;--ink:#172321;--muted:#5C6B66;--line:#D9DFDC;
  --term:#101917;--term-line:#233029;--term-text:#D7E2DC;--term-dim:#7C8F86;
  --ok:#0B6E4F;--ok-soft:#E2EFE9;--warn:#B45309;--fail:#B3372F;--fail-soft:#F5E3E1;
  --run:#3B5AA6;--run-soft:#E4E9F4;
  --mono:"IBM Plex Mono",ui-monospace,monospace;
  --sans:"IBM Plex Sans KR",sans-serif;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:var(--sans);background:var(--paper);color:var(--ink);font-size:14px}
.wrap{max-width:860px;margin:0 auto;padding:28px 20px 60px}
header{display:flex;align-items:baseline;gap:12px;margin-bottom:6px}
h1{font-size:20px;font-weight:700}
.sys{font-family:var(--mono);font-size:11px;color:var(--muted)}
.sub{color:var(--muted);font-size:12.5px;margin-bottom:20px}

.panel{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:14px}
.steps{display:flex;flex-direction:column;gap:8px}
.step{display:flex;align-items:center;gap:12px;padding:10px 12px;border:1px solid var(--line);border-radius:8px}
.step .no{font-family:var(--mono);font-size:11px;font-weight:600;color:var(--muted);width:18px}
.step .nm{font-weight:600;flex:1;font-size:13.5px}
.step .nm small{display:block;font-weight:400;color:var(--muted);font-size:11.5px;margin-top:1px}
.badge{font-family:var(--mono);font-size:10.5px;font-weight:600;padding:3px 9px;border-radius:99px;letter-spacing:.03em}
.b-idle{background:#EDEFEE;color:#8B9691}
.b-running{background:var(--run-soft);color:var(--run);animation:pulse 1.2s infinite}
.b-ok{background:var(--ok-soft);color:var(--ok)}
.b-fail{background:var(--fail-soft);color:var(--fail)}
@keyframes pulse{50%{opacity:.55}}
button{font-family:var(--sans);font-size:12.5px;font-weight:600;border:1px solid var(--line);
  background:#fff;color:var(--ink);border-radius:7px;padding:7px 14px;cursor:pointer}
button:hover:not(:disabled){border-color:var(--ok);color:var(--ok)}
button:disabled{opacity:.4;cursor:not-allowed}
.btn-primary{background:var(--ink);border-color:var(--ink);color:#fff}
.btn-primary:hover:not(:disabled){background:#233029;color:#fff;border-color:#233029}
.btn-switch{background:var(--ok);border-color:var(--ok);color:#fff}
.btn-switch:hover:not(:disabled){background:#095A41;color:#fff;border-color:#095A41}
.btn-danger{border-color:var(--fail);color:var(--fail)}
.btn-danger:hover:not(:disabled){background:var(--fail);color:#fff}
.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.toolbar .sp{flex:1}
label.chk{display:flex;gap:6px;align-items:center;font-size:12.5px;color:var(--muted);cursor:pointer}
.summary{font-family:var(--mono);font-size:12px;color:var(--muted);margin-top:10px}
.summary b{color:var(--ink)}

.term{background:var(--term);border-radius:10px;overflow:hidden}
.term-bar{display:flex;align-items:center;padding:8px 14px;border-bottom:1px solid var(--term-line)}
.term-bar span{font-family:var(--mono);font-size:11px;color:var(--term-dim)}
.term-bar button{margin-left:auto;background:transparent;color:var(--term-dim);border-color:var(--term-line);padding:3px 10px;font-size:11px}
.term-bar button:hover{color:var(--term-text);border-color:var(--term-dim)}
#log{height:380px;overflow-y:auto;padding:12px 16px;font-family:var(--mono);font-size:12px;line-height:1.65;color:var(--term-text)}
#log .t{color:var(--term-dim);margin-right:8px}
#log .k-ok{color:#8FD4B4}
#log .k-fail{color:#F0A8A2}
</style>
</head>
<body>
<div class="wrap">
  <header><h1>GeoIP 재적재 콘솔</h1><span class="sys">SBPORA · A/B 무중단 스위칭</span></header>
  <p class="sub">①~④는 실패해도 서비스에 영향 없음 (대기 테이블 작업). ⑤ 스위치만 확인 후 진행하세요.</p>

  <div class="panel">
    <div class="toolbar">
      <button class="btn-primary" id="runAll">▶ 전체 실행 (①~④, 스위치 제외)</button>
      <label class="chk"><input type="checkbox" id="useLocal"> 다운로드 생략 (폴더의 기존 CSV 사용)</label>
      <span class="sp"></span>
      <button id="btn-rollback" class="btn-danger" disabled>롤백</button>
    </div>
    <div class="summary" id="summary"></div>
  </div>

  <div class="panel steps" id="steps">
    <div class="step" data-s="download"><span class="no">①</span>
      <span class="nm">다운로드<small>MaxMind zip 수령 · 압축 해제</small></span>
      <span class="badge b-idle">대기</span><button data-run="download">실행</button></div>
    <div class="step" data-s="prepare"><span class="no">②</span>
      <span class="nm">변환 · 로컬 검증<small>CIDR→숫자 + 국가 조인 · G1 건수 · G2 샘플 판정</small></span>
      <span class="badge b-idle">대기</span><button data-run="prepare">실행</button></div>
    <div class="step" data-s="load"><span class="no">③</span>
      <span class="nm">DB 적재<small>대기 테이블 자동 판별 · TRUNCATE · 배치 INSERT · G3 건수 일치</small></span>
      <span class="badge b-idle">대기</span><button data-run="load">실행</button></div>
    <div class="step" data-s="verify"><span class="no">④</span>
      <span class="nm">검증 · 통계<small>G4 기존×0.9 · DBMS_STATS · G5 대기 테이블 판정+속도</small></span>
      <span class="badge b-idle">대기</span><button data-run="verify">실행</button></div>
    <div class="step" data-s="switch"><span class="no">⑤</span>
      <span class="nm">시노님 스위치<small>④ 통과 시에만 활성화 · 무중단 전환 · 스위치 후 자동 확인</small></span>
      <span class="badge b-idle">대기</span><button data-run="switch" class="btn-switch" disabled>스위치</button></div>
  </div>

  <div class="term">
    <div class="term-bar"><span>LIVE LOG</span><button id="clearLog">지우기</button></div>
    <div id="log"></div>
  </div>
</div>

<script>
var shown = 0;
function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}
function badge(st){
  return {idle:['b-idle','대기'],running:['b-running','진행중'],ok:['b-ok','완료'],fail:['b-fail','실패']}[st];
}
function refresh(){
  fetch('/status').then(r=>r.json()).then(function(s){
    document.querySelectorAll('.step').forEach(function(el){
      var st = s.steps[el.dataset.s];
      var b = badge(st);
      var bd = el.querySelector('.badge');
      bd.className = 'badge ' + b[0]; bd.textContent = b[1];
    });
    // 버튼 활성화 규칙
    var busy = s.busy;
    document.querySelectorAll('button[data-run]').forEach(function(b){
      var k = b.dataset.run;
      if (k === 'switch') b.disabled = busy || s.steps.verify !== 'ok' || s.switched;
      else b.disabled = busy;
    });
    document.getElementById('runAll').disabled = busy;
    document.getElementById('btn-rollback').disabled = busy || !s.switched;
    document.getElementById('useLocal').checked = s.use_local_csv;
    // 요약
    var sm = '';
    if (s.active)  sm += '활성: <b>' + s.active + '</b>';
    if (s.standby) sm += ' &nbsp;→&nbsp; 대기: <b>' + s.standby + '</b>';
    if (s.old_cnt !== null && s.new_cnt !== null)
      sm += ' &nbsp;|&nbsp; 기존 <b>' + s.old_cnt.toLocaleString() + '</b> → 신규 <b>' + s.new_cnt.toLocaleString() + '</b>';
    if (s.switched) sm += ' &nbsp;|&nbsp; <b style="color:#0B6E4F">스위치 완료</b>';
    document.getElementById('summary').innerHTML = sm;
    // 로그 증분 렌더
    var lg = document.getElementById('log');
    var stick = lg.scrollTop + lg.clientHeight >= lg.scrollHeight - 30;
    for (; shown < s.log.length; shown++){
      var ln = s.log[shown];
      var div = document.createElement('div');
      div.innerHTML = '<span class="t">' + ln.t + '</span><span class="' + (ln.k==='ok'?'k-ok':ln.k==='fail'?'k-fail':'') + '">' + esc(ln.m) + '</span>';
      lg.appendChild(div);
    }
    if (stick) lg.scrollTop = lg.scrollHeight;
  }).catch(function(){});
}
setInterval(refresh, 700); refresh();

function post(url){ return fetch(url, {method:'POST'}).then(refresh); }
document.querySelectorAll('button[data-run]').forEach(function(b){
  b.addEventListener('click', function(){
    var k = b.dataset.run;
    if (k === 'switch' && !confirm('시노님을 새 테이블로 전환합니다. 진행할까요?')) return;
    post('/run/' + k);
  });
});
document.getElementById('runAll').addEventListener('click', function(){ post('/run-all'); });
document.getElementById('btn-rollback').addEventListener('click', function(){
  if (confirm('이전 테이블로 롤백합니다. 진행할까요?')) post('/rollback');
});
document.getElementById('useLocal').addEventListener('change', function(e){
  post('/opt/local/' + (e.target.checked ? '1' : '0'));
});
document.getElementById('clearLog').addEventListener('click', function(){
  document.getElementById('log').innerHTML=''; // 화면만 지움 (파일 로그는 유지)
});
</script>
</body>
</html>
"""

# ============================================================ HTTP 서버

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif path == "/status":
            with LOCK:
                pub = {k: STATE[k] for k in
                       ("steps", "log", "busy", "use_local_csv", "active",
                        "standby", "old_cnt", "new_cnt", "switched")}
                body = json.dumps(pub, ensure_ascii=False)
            self._send(200, body)
        else:
            self._send(404, '{"err":"not found"}')

    def do_POST(self):
        path = urlparse(self.path).path
        if path.startswith("/run/"):
            step = path.split("/")[-1]
            if step in STEP_FN:
                threading.Thread(target=run_steps, args=([step],), daemon=True).start()
                self._send(200, '{"ok":true}')
                return
        elif path == "/run-all":
            threading.Thread(target=run_steps,
                             args=(["download", "prepare", "load", "verify"],),
                             daemon=True).start()
            self._send(200, '{"ok":true}')
            return
        elif path == "/rollback":
            threading.Thread(target=run_rollback, daemon=True).start()
            self._send(200, '{"ok":true}')
            return
        elif path.startswith("/opt/local/"):
            with LOCK:
                STATE["use_local_csv"] = path.endswith("/1")
            self._send(200, '{"ok":true}')
            return
        self._send(404, '{"err":"not found"}')

    def log_message(self, *a):   # 콘솔에 HTTP 액세스 로그 안 찍음
        pass


def main():
    global CFG
    try:
        CFG = load_config()
    except FileNotFoundError:
        print("geoip_config.json 이 없습니다 — geoip_reload.py 안내대로 먼저 만들어 주세요.")
        sys.exit(1)
    os.makedirs(CFG["work_dir"], exist_ok=True)
    log("콘솔 준비 완료 — 버튼으로 단계를 실행하세요. ([전체 실행]은 ①~④까지)")
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}"
    print(f"GeoIP 콘솔 실행 중: {url}  (종료: Ctrl+C)")
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n종료합니다.")


if __name__ == "__main__":
    main()
