"""
extractor.py — Oracle 매출자료 다차원 분할 추출 엔진 (재시도·병렬 지원)

분할 축(date/range/list)을 여러 개 걸어 조합(곱)만큼 구간을 만들고,
각 구간마다 쿼리→CSV. 순차 실행 시 구간 사이 sleep, 병렬 실행 시 워커 수만큼
동시 조회한다. 구간 실패 시 지정 횟수만큼 재시도한다.

필요 패키지: oracledb (데모 모드만 쓰면 없어도 됨)
"""

from __future__ import annotations

import csv
import datetime as dt
import itertools
import os
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

try:
    import oracledb
except ImportError:
    oracledb = None


QUERY_TEMPLATE = """
SELECT
    TO_CHAR(TO_DATE(tsdps.SALE_DATE, 'yyyymmdd'), 'yyyy-mm-dd') AS "매출일자",
    tsdps.STORE_CD  AS "매장코드",
    tms.STORE_NM    AS "매장명",
    CASE tsdps.SEL_TYPE_FG
        WHEN 'S' THEN 'ㅤ- ▶ ' || tmps2.PROD_NM
        ELSE tmps2.PROD_NM
    END             AS "상품명",
    SUM(tsdps.TOT_SALE_QTY)  AS "판매수량",
    SUM(tsdps.TOT_SALE_AMT)  AS "총매출액",
    SUM(tsdps.REAL_SALE_AMT) AS "실매출액"
FROM TB_SL_DAILY_PROD_SDSEL tsdps
JOIN TB_MS_STORE        tms   ON  tms.STORE_CD   = tsdps.STORE_CD
                              AND tms.HQ_BRAND_CD IN ({brands})
JOIN TB_MS_PRODUCT      tmps2 ON  tmps2.STORE_CD  = tsdps.STORE_CD
                              AND tmps2.PROD_CD    = tsdps.PROD_CD
                              AND tmps2.HQ_BRAND_CD IN ({brands})
WHERE tsdps.HQ_OFFICE_CD = :office_cd
  AND {where}
GROUP BY
    tsdps.SALE_DATE,
    tsdps.STORE_CD,
    tms.STORE_NM,
    tsdps.PROD_CD,
    tsdps.SEL_TYPE_FG,
    tsdps.SIDE_PROD_CD,
    tmps2.PROD_NM
ORDER BY
    tsdps.SALE_DATE,
    tsdps.STORE_CD,
    tsdps.SIDE_PROD_CD,
    CASE tsdps.SEL_TYPE_FG WHEN 'S' THEN tsdps.PROD_CD END DESC
"""

COL_DATE, COL_STORE_CD, COL_STORE_NM, COL_PROD, COL_QTY, COL_TOT, COL_REAL = range(7)
COLUMNS = ["매출일자", "매장코드", "매장명", "상품명", "판매수량", "총매출액", "실매출액"]


@dataclass
class SplitDim:
    type: str = "date"
    column: str = "tsdps.SALE_DATE"
    start: str = ""
    end: str = ""
    step: int = 3
    pad: int = 0
    values: list = field(default_factory=list)
    batch: int = 10


@dataclass
class ExtractConfig:
    db_user: str = ""
    db_password: str = ""
    db_dsn: str = ""
    office_cd: str = "H0393"
    brand_codes: list = field(default_factory=lambda: ["100", "101", "102", "114"])
    splits: list = field(default_factory=list)
    sleep_sec: float = 1.0
    arraysize: int = 5000
    save_empty: bool = False
    demo: bool = False
    max_retries: int = 1        # 구간 실패 시 추가 재시도 횟수
    retry_delay: float = 2.0    # 재시도 전 대기(초)
    parallel: int = 1           # 동시 실행 워커 수 (1=순차)
    query_mode: str = "auto"    # auto=기본 쿼리 / custom=직접 편집
    custom_query: str = ""      # query_mode=custom 일 때 사용할 SQL
    apply_split: bool = True    # custom 쿼리에 분할 조건을 적용할지
    max_rows_per_file: int = 0  # >0 이면 결과를 이 행수마다 파일로 분할 (0=끄기)

    def validated_brands(self):
        ok = [b.strip() for b in self.brand_codes if re.fullmatch(r"[A-Za-z0-9]+", (b or "").strip())]
        if not ok:
            raise ValueError("유효한 브랜드코드가 하나도 없습니다.")
        return ok


@dataclass
class Task:
    label: str
    condition: str
    binds: dict
    meta: dict


# ── 축별 구간 생성 ───────────────────────────────
def make_date_chunks(start_str, end_str, days):
    start = dt.datetime.strptime(start_str, "%Y%m%d").date()
    end = dt.datetime.strptime(end_str, "%Y%m%d").date()
    if end < start:
        raise ValueError("종료일이 시작일보다 빠릅니다.")
    if days < 1:
        raise ValueError("분할 일수는 1 이상이어야 합니다.")
    out, cur = [], start
    while cur <= end:
        ce = min(cur + dt.timedelta(days=days - 1), end)
        out.append((cur.strftime("%Y%m%d"), ce.strftime("%Y%m%d")))
        cur = ce + dt.timedelta(days=1)
    return out


def _gen_date(dim, i):
    return [Task(f"{s}_{e}",
                 f"{dim.column} BETWEEN :d{i}_s AND :d{i}_e",
                 {f"d{i}_s": s, f"d{i}_e": e}, {"date": (s, e)})
            for s, e in make_date_chunks(dim.start, dim.end, dim.step)]


def _gen_range(dim, i):
    try:
        lo, hi = int(dim.start), int(dim.end)
    except ValueError:
        raise ValueError(f"코드 범위 분할의 시작/끝은 숫자여야 합니다: {dim.start!r}, {dim.end!r}")
    if hi < lo:
        raise ValueError("코드 범위의 끝이 시작보다 작습니다.")
    if dim.step < 1:
        raise ValueError("코드 증가 폭은 1 이상이어야 합니다.")
    fmt = (lambda n: str(n).zfill(dim.pad)) if dim.pad > 0 else (lambda n: str(n))
    tasks, cur = [], lo
    while cur <= hi:
        top = min(cur + dim.step - 1, hi)
        a, b = fmt(cur), fmt(top)
        tasks.append(Task(f"{a}-{b}",
                          f"{dim.column} BETWEEN :d{i}_a AND :d{i}_b",
                          {f"d{i}_a": a, f"d{i}_b": b},
                          {"codes": [fmt(n) for n in range(cur, top + 1)], "code_col": dim.column}))
        cur = top + 1
    return tasks


def _gen_list(dim, i):
    vals = [v.strip() for v in dim.values if v and str(v).strip()]
    if not vals:
        raise ValueError("코드 목록이 비어 있습니다.")
    if dim.batch < 1:
        raise ValueError("묶음 크기는 1 이상이어야 합니다.")
    tasks = []
    for k in range(0, len(vals), dim.batch):
        grp = vals[k:k + dim.batch]
        ph = ",".join(f":d{i}_v{j}" for j in range(len(grp)))
        tasks.append(Task((f"{grp[0]}~{grp[-1]}" if len(grp) > 1 else grp[0]),
                          f"{dim.column} IN ({ph})",
                          {f"d{i}_v{j}": grp[j] for j in range(len(grp))},
                          {"codes": grp, "code_col": dim.column}))
    return tasks


def plan_tasks(cfg):
    # 직접 편집 + 분할 미적용 → 통째로 1회 실행
    if getattr(cfg, "query_mode", "auto") == "custom" and not cfg.apply_split:
        return [Task("custom", "", {}, {})]
    per_dim = []
    for i, dim in enumerate(cfg.splits):
        if dim.type == "date":
            per_dim.append(_gen_date(dim, i))
        elif dim.type == "range":
            per_dim.append(_gen_range(dim, i))
        elif dim.type == "list":
            per_dim.append(_gen_list(dim, i))
        else:
            raise ValueError(f"알 수 없는 분할 유형: {dim.type}")
    if not per_dim:
        return [Task("all", "", {}, {})]
    tasks = []
    for combo in itertools.product(*per_dim):
        label = "_".join(c.label for c in combo)
        cond = " AND ".join(c.condition for c in combo if c.condition)
        binds, meta = {}, {}
        for c in combo:
            binds.update(c.binds); meta.update(c.meta)
        tasks.append(Task(label, cond, binds, meta))
    return tasks


# ── 쿼리 조립 ───────────────────────────────────
def build_query(cfg, task):
    brands = ",".join(f"'{b}'" for b in cfg.validated_brands())

    if getattr(cfg, "query_mode", "auto") == "custom":
        sql = cfg.custom_query or ""
        if not sql.strip():
            raise ValueError("직접 편집 쿼리가 비어 있습니다.")
        if cfg.apply_split:
            if "{where}" not in sql:
                raise ValueError("분할 조건 적용을 켠 경우, 쿼리 안에 조건이 들어갈 위치 {where} 가 있어야 합니다.")
            sql = sql.replace("{where}", task.condition or "1=1")
        else:
            sql = sql.replace("{where}", "1=1")
        sql = sql.replace("{brands}", brands)
        sql = sql.replace("{office_cd}", cfg.office_cd)
        return sql

    # 기본(auto): 템플릿에 office 조건이 이미 있고, {where}에는 분할 조건만
    return QUERY_TEMPLATE.format(brands=brands, where=(task.condition or "1=1"))


def _fill_binds(sql, binds):
    for k in sorted(binds, key=len, reverse=True):
        sql = sql.replace(f":{k}", f"'{binds[k]}'")
    return sql


def default_query():
    """직접 편집 모드에서 불러올 기본 쿼리(치환자 포함)."""
    return QUERY_TEMPLATE.strip()


def validate_query(cfg):
    """실행 전 쿼리 문법/구성 확인. DB가 있으면 실제로 파싱만 시도한다(행 안 가져옴)."""
    try:
        tasks = plan_tasks(cfg)
        sql = build_query(cfg, tasks[0])   # {where}/{brands} 치환 및 필수 치환자 검증 포함
    except Exception as ex:  # noqa: BLE001
        return {"ok": False, "message": f"쿼리 구성 오류: {ex}"}
    if cfg.demo:
        return {"ok": True, "message": "데모 모드 — 쿼리 구성은 정상입니다. (실제 DB 파싱은 생략)"}
    if oracledb is None:
        return {"ok": False, "message": "oracledb 패키지가 없어 DB 검증을 못 합니다. (구성 자체는 정상)"}
    binds = {k: v for k, v in {"office_cd": cfg.office_cd, **tasks[0].binds}.items() if f":{k}" in sql}
    try:
        with oracledb.connect(user=cfg.db_user, password=cfg.db_password, dsn=cfg.db_dsn) as conn:
            cur = conn.cursor()
            cur.parse(sql)   # 실행하지 않고 파싱만 → 문법/객체/권한 오류를 미리 검출
            cur.close()
        return {"ok": True, "message": "쿼리 검증 통과 (문법·객체·권한 OK)"}
    except Exception as ex:  # noqa: BLE001
        return {"ok": False, "message": f"쿼리 오류: {ex}"}


def estimate(cfg):
    """첫 구간만 실제로 돌려 건수·소요시간을 재고, 전체를 추정한다."""
    tasks = plan_tasks(cfg)
    n = len(tasks)
    agg = Aggregator()
    import tempfile
    tmp = tempfile.mkdtemp(prefix="est_")
    t0 = time.perf_counter()
    try:
        if cfg.demo:
            rows, _ = extract_task_demo(cfg, tasks[0], tmp, agg)
        else:
            if oracledb is None:
                raise RuntimeError("oracledb 패키지가 없습니다.")
            conn = oracledb.connect(user=cfg.db_user, password=cfg.db_password, dsn=cfg.db_dsn)
            try:
                rows, _ = extract_task(conn, cfg, tasks[0], tmp, agg)
            finally:
                conn.close()
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    per = time.perf_counter() - t0
    rows = 0 if rows == -1 else rows
    # 전체 추정: 병렬이면 워커수로 나눔, 순차면 구간 사이 sleep 포함
    par = max(1, int(cfg.parallel or 1))
    if par > 1:
        est_total = per * n / par
    else:
        est_total = per * n + max(0, n - 1) * cfg.sleep_sec
    return {"first_rows": rows, "first_sec": round(per, 2), "task_count": n,
            "est_total_rows": rows * n, "est_total_sec": round(est_total, 1)}


def preview(cfg):
    tasks = plan_tasks(cfg)
    first = tasks[0]
    sql = build_query(cfg, first).replace(":office_cd", f"'{cfg.office_cd}'")
    sql = _fill_binds(sql, first.binds)
    est = 0 if cfg.parallel > 1 else round(max(0, len(tasks) - 1) * cfg.sleep_sec, 1)
    return {"query": sql.strip(), "task_count": len(tasks),
            "labels": [t.label for t in tasks], "est_seconds_wait": est}


def test_connection(cfg):
    if cfg.demo:
        return True, "데모 모드 — DB 접속 없이 합성 데이터로 동작합니다."
    if oracledb is None:
        return False, "oracledb 패키지가 설치되어 있지 않습니다. (pip install oracledb)"
    try:
        with oracledb.connect(user=cfg.db_user, password=cfg.db_password, dsn=cfg.db_dsn) as conn:
            with conn.cursor() as c:
                c.execute("SELECT 1 FROM DUAL"); c.fetchone()
        return True, "접속 성공"
    except Exception as ex:  # noqa: BLE001
        return False, f"접속 실패: {ex}"


# ── 집계기 (스레드 안전, 컬럼 자동 감지) ─────────
STD_NAMES = {"date": "매출일자", "store": "매장명", "product": "상품명",
             "qty": "판매수량", "tot": "총매출액", "real": "실매출액"}


class Aggregator:
    def __init__(self):
        self.by_date, self.by_store, self.by_product = {}, {}, {}
        self.preview, self.preview_limit = [], 50
        self.headers = None
        self.idx = {}
        self.standard = False
        self._lock = threading.Lock()

    def set_headers(self, cols):
        if self.headers is not None:
            return
        self.headers = list(cols)
        pos = {c: i for i, c in enumerate(cols)}
        self.idx = {k: pos.get(v) for k, v in STD_NAMES.items()}
        self.standard = all(v is not None for v in self.idx.values())

    @staticmethod
    def _num(v):
        try:
            return float(v or 0)
        except (TypeError, ValueError):
            return 0.0

    def add_rows(self, rows):
        with self._lock:
            for r in rows:
                if self.standard:
                    qty = self._num(r[self.idx["qty"]])
                    tot = self._num(r[self.idx["tot"]])
                    real = self._num(r[self.idx["real"]])
                    d = self.by_date.setdefault(str(r[self.idx["date"]]), [0.0, 0.0, 0.0]); d[0]+=qty; d[1]+=tot; d[2]+=real
                    s = self.by_store.setdefault(str(r[self.idx["store"]]), [0.0, 0.0, 0.0]); s[0]+=qty; s[1]+=tot; s[2]+=real
                    name = str(r[self.idx["product"]]).strip()
                    self.by_product[name] = self.by_product.get(name, 0.0) + qty
                if len(self.preview) < self.preview_limit:
                    self.preview.append(list(r))

    def chart_payload(self, top_n=12):
        dates = sorted(self.by_date)
        ts = sorted(self.by_store.items(), key=lambda kv: kv[1][2], reverse=True)[:top_n]
        tp = sorted(self.by_product.items(), key=lambda kv: kv[1], reverse=True)[:top_n]
        return {"columns": self.headers or COLUMNS,
                "standard": self.standard,
                "by_date": {"labels": dates,
                            "qty": [self.by_date[d][0] for d in dates],
                            "tot": [self.by_date[d][1] for d in dates],
                            "real": [self.by_date[d][2] for d in dates]},
                "top_stores": {"labels": [k for k, _ in ts], "real": [v[2] for _, v in ts]},
                "top_products": {"labels": [k for k, _ in tp], "qty": [v for _, v in tp]},
                "preview": self.preview}


def _safe_name(label):
    return re.sub(r'[<>:"/\\|?*\s]', "_", label)


def _open_part(out_dir, base, part, cols):
    """새 파트 파일을 열고 헤더를 쓴 뒤 (파일객체, writer, 파일명) 반환."""
    fname = f"{base}.csv" if part == 0 else f"{base}_part{part+1:02d}.csv"
    f = open(os.path.join(out_dir, fname), "w", newline="", encoding="utf-8-sig")
    w = csv.writer(f); w.writerow(cols)
    return f, w, fname


def extract_task(conn, cfg, task, out_dir, agg):
    sql = build_query(cfg, task)
    all_binds = {"office_cd": cfg.office_cd, **task.binds}
    binds = {k: v for k, v in all_binds.items() if f":{k}" in sql}   # 실제 쓰인 바인드만
    cur = conn.cursor()
    cur.arraysize = cfg.arraysize
    cur.prefetchrows = cfg.arraysize + 1
    cur.execute(sql, binds)
    cols = [d[0] for d in cur.description]
    agg.set_headers(cols)
    first = cur.fetchmany(cfg.arraysize)
    if not first and not cfg.save_empty:
        cur.close(); return -1, []

    base = f"{cfg.office_cd}_{_safe_name(task.label)}"
    limit = cfg.max_rows_per_file if cfg.max_rows_per_file and cfg.max_rows_per_file > 0 else 0
    files = []
    total = 0
    part = 0
    rows_in_part = 0
    f, w, fname = _open_part(out_dir, base, part, cols)
    files.append(fname)

    batch = first
    while batch:
        agg.add_rows(batch)
        if limit == 0:
            w.writerows(batch)
            total += len(batch); rows_in_part += len(batch)
        else:
            i = 0
            while i < len(batch):
                room = limit - rows_in_part
                take = batch[i:i + room]
                w.writerows(take)
                rows_in_part += len(take); total += len(take); i += len(take)
                if rows_in_part >= limit:          # 파트 가득 → 다음 파일로
                    f.close()
                    part += 1; rows_in_part = 0
                    f, w, fname = _open_part(out_dir, base, part, cols)
                    files.append(fname)
        batch = cur.fetchmany(cfg.arraysize)

    f.close()
    cur.close()
    # 마지막 파트가 비어 있으면(딱 나누어떨어진 경우) 그 빈 파일 제거
    if limit and rows_in_part == 0 and len(files) > 1:
        last = files.pop()
        try:
            os.remove(os.path.join(out_dir, last))
        except OSError:
            pass
    return total, files


# ── 데모 데이터 ─────────────────────────────────
_DEMO_PRODUCTS = ["아메리카노", "카페라떼", "바닐라라떼", "콜드브루", "자몽에이드",
                  "치즈케이크", "초코머핀", "크로플", "아이스티", "녹차프라페"]
_DEMO_STORES = [("S001", "강남역점"), ("S002", "홍대입구점"), ("S003", "판교테크노점"),
                ("S004", "부산서면점"), ("S005", "대전둔산점"), ("S006", "일산라페스타점")]


def _demo_dates(meta):
    if "date" in meta:
        s, e = meta["date"]
        d0 = dt.datetime.strptime(s, "%Y%m%d").date()
        d1 = dt.datetime.strptime(e, "%Y%m%d").date()
        out, cur = [], d0
        while cur <= d1:
            out.append(cur.strftime("%Y-%m-%d")); cur += dt.timedelta(days=1)
        return out
    return ["2024-01-01"]


def _demo_stores(meta):
    if "codes" in meta and "STORE" in meta.get("code_col", "").upper():
        return [(c, f"{c}호점") for c in meta["codes"][:40]]
    return _DEMO_STORES


def extract_task_demo(cfg, task, out_dir, agg):
    agg.set_headers(COLUMNS)
    rng = random.Random(f"{cfg.office_cd}{task.label}")
    rows = []
    for day in _demo_dates(task.meta):
        for cd, nm in _demo_stores(task.meta):
            for prod in _DEMO_PRODUCTS:
                if rng.random() < 0.35:
                    continue
                qty = rng.randint(1, 80)
                unit = rng.choice([3500, 4000, 4500, 5000, 5500, 6500])
                tot = qty * unit
                rows.append([day, cd, nm, prod, qty, tot, int(tot * rng.uniform(0.82, 1.0))])
    time.sleep(rng.uniform(0.1, 0.3))
    if not rows and not cfg.save_empty:
        return -1, []
    agg.add_rows(rows)

    base = f"{cfg.office_cd}_{_safe_name(task.label)}"
    limit = cfg.max_rows_per_file if cfg.max_rows_per_file and cfg.max_rows_per_file > 0 else 0
    files = []
    if limit == 0:
        chunks = [rows]
    else:
        chunks = [rows[i:i + limit] for i in range(0, len(rows), limit)]
    for part, chunk in enumerate(chunks):
        fname = f"{base}.csv" if part == 0 else f"{base}_part{part+1:02d}.csv"
        with open(os.path.join(out_dir, fname), "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f); w.writerow(COLUMNS); w.writerows(chunk)
        files.append(fname)
    return len(rows), files


# ── 한 구간 실행 (+ 재시도) ─────────────────────
def _interruptible_sleep(sec, cancel):
    waited = 0.0
    while waited < sec and not cancel():
        time.sleep(min(0.1, sec - waited)); waited += 0.1


def _attempt(cfg, task, conn, out_dir, agg, emit, index, cancel):
    t0 = time.perf_counter()
    attempt = 0
    while True:
        attempt += 1
        try:
            if cfg.demo:
                rows, files = extract_task_demo(cfg, task, out_dir, agg)
            else:
                rows, files = extract_task(conn, cfg, task, out_dir, agg)
            elapsed = round(time.perf_counter() - t0, 2)
            if rows == -1:
                return {"status": "empty", "rows": 0, "files": [], "elapsed": elapsed, "attempts": attempt}
            return {"status": "ok", "rows": rows, "files": files,
                    "file": files[0] if files else None, "parts": len(files),
                    "elapsed": elapsed, "attempts": attempt}
        except Exception as ex:  # noqa: BLE001
            if attempt <= cfg.max_retries and not cancel():
                emit({"type": "log", "level": "retry",
                      "msg": f"[{index}] 실패 → {cfg.retry_delay}s 후 재시도 {attempt}/{cfg.max_retries} · {ex}"})
                _interruptible_sleep(cfg.retry_delay, cancel)
                continue
            return {"status": "error", "error": str(ex),
                    "elapsed": round(time.perf_counter() - t0, 2), "attempts": attempt}


# ── 전체 실행 ───────────────────────────────────
def run_extraction(cfg, out_dir, emit, cancel=lambda: False):
    os.makedirs(out_dir, exist_ok=True)
    tasks = plan_tasks(cfg)
    agg = Aggregator()
    parallel = max(1, int(cfg.parallel or 1))

    emit({"type": "start", "total_chunks": len(tasks), "dims": len(cfg.splits),
          "sleep_sec": cfg.sleep_sec, "arraysize": cfg.arraysize, "demo": cfg.demo,
          "parallel": parallel, "max_retries": cfg.max_retries})

    state = {"total_rows": 0, "saved": 0, "files": [], "done": 0, "file_meta": []}
    lock = threading.Lock()
    run_start = time.perf_counter()

    def finish_one(i, task, res):
        with lock:
            state["done"] += 1
            done = state["done"]
            if res["status"] == "ok":
                state["total_rows"] += res["rows"]
                state["saved"] += 1
                files = res.get("files", [])
                state["files"].extend(files)
                # 파일별 메타 (결과 화면 목록용)
                parts = len(files)
                for k, fn in enumerate(files):
                    state["file_meta"].append({
                        "file": fn, "label": task.label,
                        "rows": res["rows"] if parts == 1 else None,  # 분할 시 파일별 건수는 합산 불가 → 구간 총건수만 첫 파일에
                        "chunk_rows": res["rows"], "part": k + 1, "parts": parts,
                        "elapsed": res["elapsed"],
                    })
        payload = {"type": "chunk_done", "index": i, "total": len(tasks), "label": task.label, **res}
        emit(payload)
        emit({"type": "progress", "done": done, "total": len(tasks)})

    try:
        if parallel > 1:
            # ── 병렬 ──
            pool = None
            if not cfg.demo:
                if oracledb is None:
                    raise RuntimeError("oracledb 패키지가 없습니다.")
                pool = oracledb.create_pool(user=cfg.db_user, password=cfg.db_password,
                                            dsn=cfg.db_dsn, min=parallel, max=parallel, increment=0)

            def worker(i, task):
                if cancel():
                    return i, task, {"status": "cancelled", "elapsed": 0, "attempts": 0}
                emit({"type": "chunk_start", "index": i, "total": len(tasks), "label": task.label})
                conn = pool.acquire() if pool else None
                try:
                    return i, task, _attempt(cfg, task, conn, out_dir, agg, emit, i, cancel)
                finally:
                    if conn is not None:
                        conn.close()

            with ThreadPoolExecutor(max_workers=parallel) as exso:
                futs = [exso.submit(worker, i, t) for i, t in enumerate(tasks, 1)]
                for fut in as_completed(futs):
                    i, task, res = fut.result()
                    if res["status"] == "cancelled":
                        continue
                    finish_one(i, task, res)
            if pool:
                pool.close()
        else:
            # ── 순차 (sleep + 재시도) ──
            conn = None
            if not cfg.demo:
                if oracledb is None:
                    raise RuntimeError("oracledb 패키지가 없습니다.")
                conn = oracledb.connect(user=cfg.db_user, password=cfg.db_password, dsn=cfg.db_dsn)
            try:
                for i, task in enumerate(tasks, 1):
                    if cancel():
                        emit({"type": "cancelled", "done": state["done"], "total": len(tasks)}); break
                    if i > 1 and cfg.sleep_sec > 0:
                        emit({"type": "log", "level": "wait", "msg": f"{cfg.sleep_sec}초 대기…"})
                        _interruptible_sleep(cfg.sleep_sec, cancel)
                    emit({"type": "chunk_start", "index": i, "total": len(tasks), "label": task.label})
                    res = _attempt(cfg, task, conn, out_dir, agg, emit, i, cancel)
                    finish_one(i, task, res)
            finally:
                if conn is not None:
                    conn.close()
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "msg": str(exc)})

    result = {"type": "done", "total_rows": state["total_rows"], "files": state["files"],
              "file_meta": state["file_meta"],
              "file_count": len(state["files"]), "chunk_count": state["saved"],
              "elapsed": round(time.perf_counter() - run_start, 2),
              "chart": agg.chart_payload()}
    emit(result)
    return result
