@echo off
cd /d "%~dp0"

echo ============================================
echo   Sales Extract Console - starting server
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    echo         Install from https://www.python.org
    echo         and CHECK "Add Python to PATH" during install.
    echo.
    pause
    exit /b
)

python -c "import fastapi, uvicorn" >nul 2>&1
if errorlevel 1 (
    echo Installing required packages for the first time. Please wait...
    echo.
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo [ERROR] Package install failed. Check your internet connection.
        pause
        exit /b
    )
    echo.
)

echo Browser will open shortly at  http://127.0.0.1:8000
echo (This black window IS the server. Close it to stop.)
echo.
start "" http://127.0.0.1:8000

python -m uvicorn main:app --port 8000

echo.
echo Server stopped.
pause
