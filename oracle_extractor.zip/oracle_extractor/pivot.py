"""
pivot.py — 작업 결과 CSV들을 읽어 피벗 집계

행 기준(date/store/product) 과 값(qty/tot/real) 을 골라 합계를 낸다.
표준 매출 컬럼이 아닐 경우 standard=False 로 알려준다.
"""

from __future__ import annotations

import csv
from pathlib import Path

ROW_NAME = {"date": "매출일자", "store": "매장명", "product": "상품명"}
MET_NAME = {"qty": "판매수량", "tot": "총매출액", "real": "실매출액"}


def _num(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def pivot(csv_dir, row="store", metric="real", q="", top=50):
    files = sorted(Path(csv_dir).glob("*.csv"))
    if not files:
        return {"standard": False, "labels": [], "values": [], "counts": [],
                "group_count": 0, "grand_total": 0, "row": row, "metric": metric}

    # 첫 파일 헤더로 컬럼 위치 파악
    with open(files[0], "r", encoding="utf-8-sig", newline="") as f:
        header = next(csv.reader(f), [])
    pos = {name: i for i, name in enumerate(header)}
    row_idx = pos.get(ROW_NAME.get(row, ""))
    met_idx = pos.get(MET_NAME.get(metric, ""))
    if row_idx is None or met_idx is None:
        return {"standard": False, "labels": [], "values": [], "counts": [],
                "group_count": 0, "grand_total": 0, "row": row, "metric": metric}

    q = (q or "").strip().lower()
    agg: dict[str, float] = {}
    cnt: dict[str, int] = {}
    grand = 0.0
    for path in files:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            r = csv.reader(f); next(r, None)
            for cells in r:
                if len(cells) <= max(row_idx, met_idx):
                    continue
                key = cells[row_idx]
                if q and q not in key.lower():
                    continue
                v = _num(cells[met_idx])
                agg[key] = agg.get(key, 0.0) + v
                cnt[key] = cnt.get(key, 0) + 1
                grand += v

    items = sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:top]
    return {"standard": True, "row": row, "metric": metric,
            "labels": [k for k, _ in items], "values": [v for _, v in items],
            "counts": [cnt[k] for k, _ in items],
            "group_count": len(agg), "grand_total": grand}
